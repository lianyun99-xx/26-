#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
轮腿式四足机器人步态可视化工具（正确摆动相与支撑相）

该脚本用于可视化轮腿式四足机器人的对角线步态运动，正确实现：
1. 摆动相：轮子抬离地面，向前摆动
2. 支撑相：轮子接触地面，提供支撑和推进
3. 机身保持相对稳定（不会有大的上下波动）
4. 正确的对角线步态：左后腿和右前腿同步运动
"""

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
import math

# 配置matplotlib支持中文字体
plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'Arial Unicode MS', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题

# 常量定义
PI = math.pi
STRIDE_LENGTH = 0.2  # 步长20cm
LIFT_HEIGHT = 0.05   # 抬升高度5cm（摆动相时轮子离地高度）
GAIT_CYCLE_TIME = 1.0  # 步态周期1秒

# 机械结构参数
HIP_LENGTH = 0.185     # 髋关节到膝关节的长度 (m)
KNEE_LENGTH = 0.215    # 膝关节到踝关节的长度 (m)
WHEEL_RADIUS = 0.05    # 轮子半径 (m)

# 机器人机身参数
BODY_LENGTH = 0.4      # 机身长度 (m)
BODY_WIDTH = 0.2       # 机身宽度 (m)
BODY_HEIGHT = 0.5    # 机身离地高度 (m)

# 腿部相对位置（相对于机身中心）
# 索引顺序: 0=前右腿(FR), 1=前左腿(FL), 2=后右腿(HR), 3=后左腿(HL)
LEG_POSITIONS = [
    [BODY_LENGTH/2, BODY_WIDTH/2],   # 前右腿 (FR)
    [BODY_LENGTH/2, -BODY_WIDTH/2],  # 前左腿 (FL) 
    [-BODY_LENGTH/2, BODY_WIDTH/2],  # 后右腿 (HR)
    [-BODY_LENGTH/2, -BODY_WIDTH/2]  # 后左腿 (HL)
]

# 方向枚举
GAIT_DIRECTION_FORWARD = 0
GAIT_DIRECTION_BACKWARD = 1

# 相位枚举
GAIT_PHASE_SWING = 0      # 摆动相（轮子抬离地面）
GAIT_PHASE_STANCE = 1     # 支撑相（轮子接触地面）

class Cycloid2DPose:
    """2D摆线轨迹位姿结构体"""
    def __init__(self, x=0.0, y=0.0):
        self.x = x
        self.y = y

class LegGaitState:
    """单腿步态状态结构体"""
    def __init__(self):
        self.x_start = 0.0
        self.x_target = 0.0
        self.y_start = 0.0
        self.y_target = 0.0
        self.lift_height = 0.0
        self.cycle_time = 0.0
        self.start_time = 0.0
        self.phase = GAIT_PHASE_SWING
        self.is_active = 0

class QuadrupedGait:
    """四足机器人整体步态结构体"""
    def __init__(self):
        self.legs = [LegGaitState() for _ in range(4)]
        self.gait_cycle_time = 0.0
        self.stride_length = 0.0
        self.lift_height = 0.0
        self.direction = GAIT_DIRECTION_FORWARD
        self.start_time = 0.0
        self.is_running = 0
        self.body_position = 0.0  # 机身X坐标（用于显示整体移动）

def cycloid_2d_arch_trajectory(t, starttime, cycle_time, x_start, x_target, y_start, y_target, lift_height):
    """
    生成2D摆线拱形轨迹（摆动相）
    
    参数:
        t: 当前时间
        starttime: 开始时间
        cycle_time: 周期时间
        x_start: X起始位置
        x_target: X目标位置
        y_start: Y起始位置
        y_target: Y目标位置
        lift_height: 抬升高度
    
    返回:
        Cycloid2DPose: 当前位置
    """
    current_pose = Cycloid2DPose()
    error_time = t - starttime
    
    if error_time < 0.0:
        current_pose.x = x_start
        current_pose.y = y_start
        return current_pose
    elif error_time >= cycle_time:
        current_pose.x = x_target
        current_pose.y = y_target
        return current_pose
    
    dt = error_time / cycle_time
    delta_x = x_target - x_start
    current_pose.x = x_start + delta_x * (dt - math.sin(2.0 * PI * dt) / (2.0 * PI))
    
    # 摆动相有抬升高度
    current_pose.y = y_start + (y_target - y_start) * dt + lift_height * (1.0 - math.cos(2.0 * PI * dt)) / 2.0
    
    return current_pose

def straight_line_trajectory(t, starttime, cycle_time, x_start, x_target, y_start, y_target):
    """
    生成2D直线轨迹（支撑相）
    
    参数:
        t: 当前时间
        starttime: 开始时间
        cycle_time: 周期时间
        x_start: X起始位置
        x_target: X目标位置
        y_start: Y起始位置
        y_target: Y目标位置
    
    返回:
        Cycloid2DPose: 当前位置
    """
    current_pose = Cycloid2DPose()
    error_time = t - starttime
    
    if error_time < 0.0:
        current_pose.x = x_start
        current_pose.y = y_start
        return current_pose
    elif error_time >= cycle_time:
        current_pose.x = x_target
        current_pose.y = y_target
        return current_pose
    
    dt = error_time / cycle_time
    current_pose.x = x_start + (x_target - x_start) * dt
    current_pose.y = y_start + (y_target - y_start) * dt
    
    return current_pose

def inverse_kinematics(x, y):
    """
    逆运动学计算
    
    参数:
        x: 末端X坐标
        y: 末端Y坐标
    
    返回:
        tuple: (theta1, theta2) 髋关节和膝关节角度
    """
    # 计算距离
    dist = math.sqrt(x**2 + y**2)
    
    # 检查是否在工作空间内
    if dist > HIP_LENGTH + KNEE_LENGTH or dist < abs(HIP_LENGTH - KNEE_LENGTH):
        return (0.0, 0.0)  # 超出工作空间，返回默认角度
    
    # 计算膝关节角度（余弦定理）
    cos_theta2 = (HIP_LENGTH**2 + KNEE_LENGTH**2 - dist**2) / (2 * HIP_LENGTH * KNEE_LENGTH)
    cos_theta2 = max(-1.0, min(1.0, cos_theta2))  # 限制范围
    theta2 = math.acos(cos_theta2)
    
    # 计算髋关节角度
    sin_theta1 = (KNEE_LENGTH * math.sin(theta2)) / dist
    cos_theta1 = (HIP_LENGTH**2 + dist**2 - KNEE_LENGTH**2) / (2 * HIP_LENGTH * dist)
    
    # 调整符号
    if x < 0:
        theta1 = math.pi - math.atan2(sin_theta1, cos_theta1)
    else:
        theta1 = math.atan2(sin_theta1, cos_theta1)
    
    return (theta1, theta2)

def init_quadruped_gait(gait, cycle_time, stride_length, lift_height, direction):
    """
    初始化四足机器人步态结构体
    
    参数:
        gait: QuadrupedGait实例
        cycle_time: 周期时间
        stride_length: 步长
        lift_height: 抬升高度
        direction: 运动方向
    """
    # 初始化所有字段
    gait.gait_cycle_time = cycle_time
    gait.stride_length = stride_length
    gait.lift_height = lift_height
    gait.direction = direction
    gait.is_running = 0
    gait.body_position = 0.0
    
    for i in range(4):
        gait.legs[i].cycle_time = cycle_time
        gait.legs[i].lift_height = lift_height
        gait.legs[i].is_active = 0
        gait.legs[i].phase = GAIT_PHASE_SWING

def start_quadruped_gait(gait, current_time):
    """
    启动四足机器人步态
    
    参数:
        gait: QuadrupedGait实例
        current_time: 当前时间
    """
    gait.start_time = current_time
    gait.is_running = 1
    gait.body_position = 0.0
    
    half_cycle = gait.gait_cycle_time / 2.0
    
    for i in range(4):
        gait.legs[i].is_active = 1
        
        if gait.direction == GAIT_DIRECTION_FORWARD:
            # 前进方向：对角线1（0=前右, 3=后左）腿摆动相，对角线2（1=前左, 2=后右）腿支撑相
            if i == 0 or i == 3:  # 对角线1: 前右腿和后左腿
                gait.legs[i].phase = GAIT_PHASE_SWING
                gait.legs[i].start_time = current_time
                gait.legs[i].x_start = 0.0
                gait.legs[i].x_target = gait.stride_length
                gait.legs[i].y_start = 0.0
                gait.legs[i].y_target = 0.0
            else:  # 对角线2: 前左腿和后右腿
                gait.legs[i].phase = GAIT_PHASE_STANCE
                gait.legs[i].start_time = current_time + half_cycle
                gait.legs[i].x_start = gait.stride_length
                gait.legs[i].x_target = 0.0
                gait.legs[i].y_start = 0.0
                gait.legs[i].y_target = 0.0
        else:
            # 后退方向：对角线1（0=前右, 3=后左）腿支撑相，对角线2（1=前左, 2=后右）腿摆动相
            if i == 0 or i == 3:  # 对角线1: 前右腿和后左腿
                gait.legs[i].phase = GAIT_PHASE_STANCE
                gait.legs[i].start_time = current_time
                gait.legs[i].x_start = gait.stride_length
                gait.legs[i].x_target = 0.0
                gait.legs[i].y_start = 0.0
                gait.legs[i].y_target = 0.0
            else:  # 对角线2: 前左腿和后右腿
                gait.legs[i].phase = GAIT_PHASE_SWING
                gait.legs[i].start_time = current_time + half_cycle
                gait.legs[i].x_start = 0.0
                gait.legs[i].x_target = gait.stride_length
                gait.legs[i].y_start = 0.0
                gait.legs[i].y_target = 0.0

def get_leg_trajectory(gait, leg_index, current_time):
    """
    获取指定腿部的实时轨迹位置（相对于髋关节）
    
    参数:
        gait: QuadrupedGait实例
        leg_index: 腿部索引
        current_time: 当前时间
    
    返回:
        Cycloid2DPose: 相对于髋关节的位置
    """
    pose = Cycloid2DPose(0.0, 0.0)
    
    if leg_index >= 4 or not gait.is_running or not gait.legs[leg_index].is_active:
        return pose
    
    leg = gait.legs[leg_index]
    elapsed_time = current_time - gait.start_time
    full_cycle_time = gait.gait_cycle_time
    half_cycle_time = full_cycle_time / 2.0
    
    cycle_count = int(elapsed_time / full_cycle_time)
    time_in_cycle = elapsed_time - cycle_count * full_cycle_time
    
    # 计算机身位置 - 对角线步态下，每半周期移动步长的一半
    if time_in_cycle < half_cycle_time:
        # 前半周期：对角线1的腿摆动，对角线2的腿支撑
        gait.body_position = cycle_count * gait.stride_length + (time_in_cycle / half_cycle_time) * (gait.stride_length / 2)
    else:
        # 后半周期：对角线2的腿摆动，对角线1的腿支撑
        gait.body_position = cycle_count * gait.stride_length + (gait.stride_length / 2) + ((time_in_cycle - half_cycle_time) / half_cycle_time) * (gait.stride_length / 2)
    
    if gait.direction == GAIT_DIRECTION_FORWARD:
        # 前进方向：对角线1（0=前右, 3=后左）腿摆动相，对角线2（1=前左, 2=后右）腿支撑相
        if leg_index == 0 or leg_index == 3:  # 对角线1: 前右腿和后左腿
            if time_in_cycle < half_cycle_time:
                # 前半周期：摆动相
                leg.phase = GAIT_PHASE_SWING
                leg.start_time = gait.start_time + cycle_count * full_cycle_time
                leg.x_start = 0.0
                leg.x_target = gait.stride_length
                leg.y_start = 0.0
                leg.y_target = 0.0
                
                pose = cycloid_2d_arch_trajectory(current_time, leg.start_time, half_cycle_time,
                                               leg.x_start, leg.x_target,
                                               leg.y_start, leg.y_target,
                                               leg.lift_height)
            else:
                # 后半周期：支撑相
                leg.phase = GAIT_PHASE_STANCE
                leg.start_time = gait.start_time + cycle_count * full_cycle_time + half_cycle_time
                leg.x_start = gait.stride_length
                leg.x_target = 0.0
                leg.y_start = 0.0
                leg.y_target = 0.0
                
                pose = straight_line_trajectory(current_time, leg.start_time, half_cycle_time,
                                              leg.x_start, leg.x_target,
                                              leg.y_start, leg.y_target)
        else:  # 对角线2: 前左腿和后右腿
            if time_in_cycle < half_cycle_time:
                # 前半周期：支撑相
                leg.phase = GAIT_PHASE_STANCE
                leg.start_time = gait.start_time + cycle_count * full_cycle_time
                leg.x_start = gait.stride_length
                leg.x_target = 0.0
                leg.y_start = 0.0
                leg.y_target = 0.0
                
                pose = straight_line_trajectory(current_time, leg.start_time, half_cycle_time,
                                              leg.x_start, leg.x_target,
                                              leg.y_start, leg.y_target)
            else:
                # 后半周期：摆动相
                leg.phase = GAIT_PHASE_SWING
                leg.start_time = gait.start_time + cycle_count * full_cycle_time + half_cycle_time
                leg.x_start = 0.0
                leg.x_target = gait.stride_length
                leg.y_start = 0.0
                leg.y_target = 0.0
                
                pose = cycloid_2d_arch_trajectory(current_time, leg.start_time, half_cycle_time,
                                               leg.x_start, leg.x_target,
                                               leg.y_start, leg.y_target,
                                               leg.lift_height)
    else:
        # 后退方向：对角线1（0=前右, 3=后左）腿支撑相，对角线2（1=前左, 2=后右）腿摆动相
        if leg_index == 0 or leg_index == 3:  # 对角线1: 前右腿和后左腿
            if time_in_cycle < half_cycle_time:
                # 前半周期：支撑相
                leg.phase = GAIT_PHASE_STANCE
                leg.start_time = gait.start_time + cycle_count * full_cycle_time
                leg.x_start = gait.stride_length
                leg.x_target = 0.0
                leg.y_start = 0.0
                leg.y_target = 0.0
                
                pose = straight_line_trajectory(current_time, leg.start_time, half_cycle_time,
                                              leg.x_start, leg.x_target,
                                              leg.y_start, leg.y_target)
            else:
                # 后半周期：摆动相
                leg.phase = GAIT_PHASE_SWING
                leg.start_time = gait.start_time + cycle_count * full_cycle_time + half_cycle_time
                leg.x_start = 0.0
                leg.x_target = gait.stride_length
                leg.y_start = 0.0
                leg.y_target = 0.0
                
                pose = cycloid_2d_arch_trajectory(current_time, leg.start_time, half_cycle_time,
                                               leg.x_start, leg.x_target,
                                               leg.y_start, leg.y_target,
                                               leg.lift_height)
        else:  # 对角线2: 前左腿和后右腿
            if time_in_cycle < half_cycle_time:
                # 前半周期：摆动相
                leg.phase = GAIT_PHASE_SWING
                leg.start_time = gait.start_time + cycle_count * full_cycle_time
                leg.x_start = 0.0
                leg.x_target = gait.stride_length
                leg.y_start = 0.0
                leg.y_target = 0.0
                
                pose = cycloid_2d_arch_trajectory(current_time, leg.start_time, half_cycle_time,
                                               leg.x_start, leg.x_target,
                                               leg.y_start, leg.y_target,
                                               leg.lift_height)
            else:
                # 后半周期：支撑相
                leg.phase = GAIT_PHASE_STANCE
                leg.start_time = gait.start_time + cycle_count * full_cycle_time + half_cycle_time
                leg.x_start = gait.stride_length
                leg.x_target = 0.0
                leg.y_start = 0.0
                leg.y_target = 0.0
                
                pose = straight_line_trajectory(current_time, leg.start_time, half_cycle_time,
                                              leg.x_start, leg.x_target,
                                              leg.y_start, leg.y_target)
    
    return pose

def draw_leg(ax, body_x, leg_x, leg_y, leg_index, color, phase):
    """
    绘制轮腿式机器人的腿部
    
    参数:
        ax: matplotlib轴
        body_x: 机身X位置
        leg_x: 腿部相对于髋关节的X坐标
        leg_y: 腿部相对于髋关节的Y坐标
        leg_index: 腿部索引
        color: 腿部颜色
        phase: 当前相位
    """
    # 计算髋关节全局位置
    hip_x = body_x + LEG_POSITIONS[leg_index][0]
    hip_y = LEG_POSITIONS[leg_index][1]
    
    # 计算关节角度
    theta1, theta2 = inverse_kinematics(leg_x, leg_y)
    
    # 计算关节位置
    knee_x = hip_x + HIP_LENGTH * math.cos(theta1)
    knee_y = hip_y + HIP_LENGTH * math.sin(theta1)
    ankle_x = hip_x + leg_x
    ankle_y = hip_y + leg_y
    
    # 绘制腿部连杆
    ax.plot([hip_x, knee_x, ankle_x], [hip_y, knee_y, ankle_y], f'{color}-', linewidth=3)
    
    # 绘制关节
    ax.scatter([hip_x, knee_x, ankle_x], [hip_y, knee_y, ankle_y], c=color, s=50)
    
    # 绘制轮子
    wheel_angle = math.atan2(ankle_y - knee_y, ankle_x - knee_x)  # 轮子方向
    
    wheel_points = []
    for i in range(36):
        angle = (i / 36) * 2 * math.pi
        wx = ankle_x + WHEEL_RADIUS * math.cos(angle + wheel_angle)
        wy = ankle_y + WHEEL_RADIUS * math.sin(angle + wheel_angle)
        wheel_points.append((wx, wy))
    
    wheel_x, wheel_y = zip(*wheel_points)
    ax.plot(wheel_x, wheel_y, f'{color}-', linewidth=2)
    
    # 添加相位指示器
    phase_text = "摆动相" if phase == GAIT_PHASE_SWING else "支撑相"
    ax.text(0.05, 0.95, f'相位: {phase_text}', transform=ax.transAxes, 
            verticalalignment='top', fontsize=9, bbox=dict(facecolor='white', alpha=0.7))
    
    # 用颜色区分相位
    if phase == GAIT_PHASE_SWING:
        ax.scatter(ankle_x, ankle_y, c='red', s=80, marker='o', label='摆动相')
    else:
        ax.scatter(ankle_x, ankle_y, c='green', s=80, marker='o', label='支撑相')

def draw_robot_body(ax, body_x, body_trajectory):
    """
    绘制机器人机身
    
    参数:
        ax: matplotlib轴
        body_x: 机身X位置
        body_trajectory: 机身轨迹历史
    """
    # 绘制机身矩形
    body_corners = [
        (body_x - BODY_LENGTH/2, -BODY_WIDTH/2),
        (body_x - BODY_LENGTH/2, BODY_WIDTH/2),
        (body_x + BODY_LENGTH/2, BODY_WIDTH/2),
        (body_x + BODY_LENGTH/2, -BODY_WIDTH/2),
        (body_x - BODY_LENGTH/2, -BODY_WIDTH/2)
    ]
    
    body_x_coords, body_y_coords = zip(*body_corners)
    ax.plot(body_x_coords, body_y_coords, 'k-', linewidth=3)
    
    # 绘制机身中心点
    ax.scatter(body_x, 0, c='red', s=100, marker='x', label='机身中心')
    
    # 绘制机身轨迹
    if len(body_trajectory) > 1:
        traj_x, traj_y = zip(*body_trajectory)
        ax.plot(traj_x, traj_y, 'b-', linewidth=2, alpha=0.7, label='机身轨迹')
    
    # 添加机身标签
    ax.text(body_x, BODY_WIDTH/2 + 0.05, '轮腿式四足机器人', horizontalalignment='center', fontsize=10)

# 可视化部分
class GaitVisualizer:
    """步态可视化类（完整机器人形态）"""
    def __init__(self):
        # 只创建一个主视图
        self.fig, self.ax = plt.subplots(figsize=(12, 8))
        self.ax.set_xlim(-0.5, 1.5)
        self.ax.set_ylim(-0.3, 0.3)
        self.ax.set_xlabel('X Position (m)')
        self.ax.set_ylabel('Y Position (m)')
        self.ax.set_title('轮腿式四足机器人对角线步态 (完整机器人形态)')
        self.ax.grid(True)
        self.ax.set_aspect('equal')
        
        # 添加地面线
        self.ax.plot([-1, 2], [0, 0], 'k-', linewidth=2)
        self.ax.text(1.5, 0.02, '地面', fontsize=10)
        
        # 存储轨迹历史
        self.body_trajectory = []
        
        # 初始化步态
        self.gait = QuadrupedGait()
        init_quadruped_gait(self.gait, GAIT_CYCLE_TIME, STRIDE_LENGTH, LIFT_HEIGHT, GAIT_DIRECTION_BACKWARD)
        self.start_time = 0.0
        self.current_time = 0.0
        
        # 添加图例说明
        self.ax.plot([], [], 'r-', linewidth=3, label='对角线1 (前右+后左)')
        self.ax.plot([], [], 'b-', linewidth=3, label='对角线2 (前左+后右)')
        self.ax.legend(loc='upper right')
        
        # 添加全局说明
        self.fig.text(0.5, 0.01, 
                     '说明: 1. 摆动相: 轮子抬离地面，向前摆动\n'
                     '     2. 支撑相: 轮子接触地面，提供支撑和推进\n'
                     '     3. 对角线1(前右腿+后左腿)同步运动\n'
                     '     4. 对角线2(前左腿+后右腿)同步运动\n'
                     '     5. 步长: 20cm | 抬升高度: 5cm | 步态周期: 1秒', 
                     ha='center', fontsize=10, bbox=dict(facecolor='yellow', alpha=0.3))
    
    def start(self):
        """开始可视化"""
        self.start_time = 0.0
        self.current_time = 0.0
        self.body_trajectory = []
        
        start_quadruped_gait(self.gait, self.start_time)
        
        # 创建动画
        self.ani = FuncAnimation(self.fig, self.update, frames=np.arange(0, 5, 0.05),
                               blit=False, interval=50)
        plt.tight_layout(rect=[0, 0.05, 1, 1])  # 为底部说明留出空间
        plt.show()
    
    def update(self, frame):
        """
        更新动画帧
        
        参数:
            frame: 当前帧时间
        """
        self.current_time = frame
        
        # 清除主视图
        self.ax.clear()
        self.ax.set_xlim(-0.5, 1.5)
        self.ax.set_ylim(-0.3, 0.3)
        self.ax.set_xlabel('X Position (m)')
        self.ax.set_ylabel('Y Position (m)')
        self.ax.set_title('轮腿式四足机器人对角线步态 (完整机器人形态)')
        self.ax.grid(True)
        self.ax.set_aspect('equal')
        
        # 添加地面线
        self.ax.plot([-1, 2], [0, 0], 'k-', linewidth=2)
        self.ax.text(1.5, 0.02, '地面', fontsize=10)
        
        # 绘制四条腿和机身
        # 对角线1: 0=前右腿, 3=后左腿 用红色
        # 对角线2: 1=前左腿, 2=后右腿 用蓝色
        colors = ['r', 'b', 'b', 'r']
        leg_names = ['前右腿 (FR)', '前左腿 (FL)', '后右腿 (HR)', '后左腿 (HL)']
        
        # 获取机身位置
        body_x = self.gait.body_position
        
        # 存储机身轨迹
        self.body_trajectory.append((body_x, 0))
        
        # 绘制机身
        draw_robot_body(self.ax, body_x, self.body_trajectory)
        
        # 绘制四条腿
        for i in range(4):
            # 获取腿部轨迹（相对于髋关节）
            pose = get_leg_trajectory(self.gait, i, self.current_time)
            leg = self.gait.legs[i]
            
            # 绘制腿部
            draw_leg(self.ax, body_x, pose.x, pose.y, i, colors[i], leg.phase)
            
            # 添加腿标签
            hip_x = body_x + LEG_POSITIONS[i][0]
            hip_y = LEG_POSITIONS[i][1]
            self.ax.text(hip_x, hip_y + 0.05, leg_names[i], 
                         horizontalalignment='center', fontsize=8,
                         bbox=dict(facecolor='white', alpha=0.7))
        
        # 添加当前状态文本
        status_text = (f'当前时间: {self.current_time:.2f}s | 机身位置: {body_x:.2f}m\n'
                       f'步态周期进度: {((self.current_time % GAIT_CYCLE_TIME)/GAIT_CYCLE_TIME)*100:.1f}%')
        self.ax.text(0.05, -0.25, status_text, 
                     bbox=dict(facecolor='white', alpha=0.7))

if __name__ == '__main__':
    print("轮腿式四足机器人步态可视化工具 - 摆动相与支撑相版")
    print("关键特点:")
    print("1. 正确实现摆动相：轮子抬离地面，向前摆动")
    print("2. 正确实现支撑相：轮子接触地面，提供支撑和推进")
    print("3. 机身保持相对稳定（不会有大的上下波动）")
    print("4. 正确实现对角线步态：左后腿和右前腿同步运动")
    print("按Ctrl+C退出")
    
    # 创建并启动可视化
    visualizer = GaitVisualizer()
    visualizer.start()

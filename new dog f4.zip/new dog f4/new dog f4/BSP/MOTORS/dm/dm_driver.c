#include "dm_driver.h"

#include <string.h>

extern CAN_HandleTypeDef hcan1;
DM_Motor_t Arm_Motors[4];

#define P_MIN -12.5f
#define P_MAX 12.5f
#define V_MIN -30.0f
#define V_MAX 30.0f
#define KP_MIN 0.0f
#define KP_MAX 500.0f
#define KD_MIN 0.0f
#define KD_MAX 5.0f
#define T_MIN -10.0f
#define T_MAX 10.0f
#define DM_EMA_ALPHA 0.2f

// 达妙协议数值映射转换函数
static float uint_to_float(int x_int, float x_min, float x_max, int bits) {
    float span = x_max - x_min;
    float offset = x_min;
    return ((float)x_int) * span / ((float)((1 << bits) - 1)) + offset;
}

static int float_to_uint(float x, float x_min, float x_max, int bits) {
    float span = x_max - x_min;
    float offset = x_min;
    return (int)((x - offset) * ((float)((1 << bits) - 1)) / span);
}


// 初始化电机数据
void DM_Init(void){

    for(int i=0; i<4; i++) {
        Arm_Motors[i].ID = i + 1; // 默认ID: 1,2,3,4
        Arm_Motors[i].POS = 0.0f;
        Arm_Motors[i].VEL = 0.0f;
        Arm_Motors[i].Filter_VEL = 0.0f;
        Arm_Motors[i].T = 0.0f;
        Arm_Motors[i].T_MOS = 0;
        Arm_Motors[i].T_Rotor = 0;
    }
}

// 使能电机
void DM_Motor_Enable(uint16_t id)
{
	CAN_TxHeaderTypeDef header;
    uint8_t TxData[8] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFC};
    uint32_t mailbox;

    header.StdId = id; // 达妙电机接收 ID
    header.IDE = CAN_ID_STD;
    header.RTR = CAN_RTR_DATA;
    header.DLC = 8;

    HAL_CAN_AddTxMessage(&hcan1, &header, TxData, &mailbox);
}

// 失能电机
void DM_Motor_Disable(uint16_t id)
{
	CAN_TxHeaderTypeDef header;
    uint8_t TxData[8] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFD};
    uint32_t mailbox;

    header.StdId = id; // 达妙电机接收 ID
    header.IDE = CAN_ID_STD;
    header.RTR = CAN_RTR_DATA;
    header.DLC = 8;

    HAL_CAN_AddTxMessage(&hcan1, &header, TxData, &mailbox);
}
// 达妙电机控制：MIT模式发送
uint8_t DM_Send_Ctrl(uint16_t id,float p_des,float v_des,float Kp,float Kd,float t_ff) {
    CAN_TxHeaderTypeDef header;
    uint8_t TxData[8];
    uint32_t mailbox;

    header.StdId = id; // 达妙电机接收 ID
    header.IDE = CAN_ID_STD;
    header.RTR = CAN_RTR_DATA;
    header.DLC = 8;


    uint16_t p_int = float_to_uint(p_des, P_MIN, P_MAX, 16);
    uint16_t v_int = float_to_uint(v_des, V_MIN, V_MAX, 12);
    uint16_t kp_int = float_to_uint(Kp, KP_MIN, KP_MAX, 12);
    uint16_t kd_int = float_to_uint(Kd, KD_MIN, KD_MAX, 12);
    uint16_t t_int = float_to_uint(t_ff, T_MIN, T_MAX, 12);

    TxData[0] = p_int >> 8;
    TxData[1] = p_int & 0xFF;
    TxData[2] = v_int >> 4;
    TxData[3] = ((v_int & 0xF) << 4) | (kp_int >> 8);
    TxData[4] = kp_int & 0xFF;
    TxData[5] = kd_int >> 4;
    TxData[6] = ((kd_int & 0xF) << 4) | (t_int >> 8);
    TxData[7] = t_int & 0xFF;

    return HAL_CAN_AddTxMessage(&hcan1, &header, TxData, &mailbox);
}

//解码函数
void DM_RX_Decode(uint8_t* data, uint16_t can_id) {

    // ID 范围 0x01 ~ 0x04 对应数组下标 0 ~ 3
    int idx = (can_id & 0x0F) - 1;

    if (idx < 0 || idx >= 4) return;

    DM_Motor_t *motor = &Arm_Motors[idx];

    // 1. ID 和 错误码 (Byte 0)
    motor->ID = data[0] & 0x0F;
    motor->ERR = data[0] >> 4;

    // 2. 位置 (Byte 1-2)
    uint16_t p_int = (data[1] << 8) | data[2];
    motor->POS = uint_to_float(p_int, P_MIN, P_MAX, 16);

    // 3. 速度 (Byte 3-4)
    uint16_t v_int = (data[3] << 4) | (data[4] >> 4);
    motor->VEL = uint_to_float(v_int, V_MIN, V_MAX, 12);

    // 4.EMA 滤波速度 Y_new = alpha * X_raw + (1 - alpha) * Y_old
    motor->Filter_VEL = (DM_EMA_ALPHA * motor->VEL) + ((1.0f - DM_EMA_ALPHA) * motor->Filter_VEL);

    // 5. 扭矩 (Byte 4-5)
    uint16_t t_int = ((data[4] & 0x0F) << 8) | data[5];
    motor->T = uint_to_float(t_int, T_MIN, T_MAX, 12);

    // 6. 温度 (Byte 6-7)
    motor-> T_MOS = (int8_t)data[6];//驱动上MOS的平均温度
    motor-> T_Rotor = (int8_t)data[7];//电机内部线圈的平均温度
}

#ifndef __3508_DRIVER_H__
#define __3508_DRIVER_H__


/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include <stdint.h>

// 1. 电机数据结构体
typedef struct {
    // 反馈数据
    uint16_t cur_angle;      // 0-8191 当前机械角度
    int16_t  cur_speed;      // 转速 RPM
    float    filter_speed;
    int16_t  actual_current; // 实际电流
    uint8_t  temperature;    // 温度

    // 角度

    uint16_t last_angle;     // 上一次的角度
    int64_t  total_angle;    // 累计总角度
    int32_t  total_round; //圈数计数

    // 控制数据
    int64_t  target_angle;  //目标角度
    float    target_speed;   // 目标速度
    int16_t  Out_Current;    // 输出电流
    float    speed_err_sum;        // PID积分
    float    position_err_sum;
    float    err_last;        // PID积分

} Motor_3508_T;



// 2.PID参数结构体
typedef struct {
    float Kp;       // 比例系数
    float Ki;       // 积分系数
    float Kd;       // 微分系数
    float Max_Out;  // 输出限幅
    float Max_Sum;  // 积分限幅
} PID_3508_T;

// 3. 全局变量
extern Motor_3508_T Motors[4];
extern PID_3508_T Speed_PID;
extern PID_3508_T Position_PID;

// 4. 函数声明

//1.初始化CAN通信及滤波器
void CAN_Filter_Init(void);

//2.初始化电机数据
void D3508_Init(void);

//3. 发送控制电流
void send_current(void);

//4.5. PID计算
void PID_Calc_Speed(int i);
void PID_Calc_Position(int i, float target_angle);

//6.功率限制函数
int16_t Power_Limit(float desire_current, float rpm);

// 7.接收中断与解算
void HAL_CAN_RxFifo0MsgPendingCallback(CAN_HandleTypeDef *hcan);
void HAL_CAN_ErrorCallback(CAN_HandleTypeDef *hcan);


#endif /* BSP_DRIVER_H_ */




#include "3508_driver.h"

#include <string.h>
#include "main.h"

extern CAN_HandleTypeDef hcan1;

// --- 1. 全局变量定义 ---
Motor_3508_T Motors[4];

// PID 参数初始化
PID_3508_T Speed_PID = {
    .Kp = 3.0f,
    .Ki = 0.3f,
    .Kd = 0.0f,
    .Max_Out = 16000.0f,
    .Max_Sum = 10000.0f
};

PID_3508_T Position_PID = {
    .Kp = 1.0f,    // 需调试：越大响应越快，太大会震荡
    .Ki = 0.03f,
    .Kd = 0.15f,    // 需调试：阻尼项，防止超调
    .Max_Out = 6000.0f, // 最大转速限制 (RPM)
    .Max_Sum = 0.0f
};


//功率限制参数
#define POWER_LIMIT 162.0f   // 限制最大功率 162W
#define Kt   0.0156f    // 转矩常数 (Nm/A)  3508电机参数: Kt ≈ 0.3 Nm/A/19 （减速比）
#define Int_Current   819.2f  // 16384/20 = 819.2 (Value/A)  C620电调: 16384 = 20A

// EMA 滤波系数
#define D3508_EMA_ALPHA 0.3f
static const float Ts = 0.005f;


//1.配置can通信
void CAN_Filter_Init(void) {
    CAN_FilterTypeDef can_filter_st;

    can_filter_st.FilterActivation = ENABLE;
    can_filter_st.FilterMode = CAN_FILTERMODE_IDMASK;
    can_filter_st.FilterScale = CAN_FILTERSCALE_32BIT;
    can_filter_st.FilterIdHigh = 0x0000;
    can_filter_st.FilterIdLow = 0x0000;
    can_filter_st.FilterMaskIdHigh = 0x0000;
    can_filter_st.FilterMaskIdLow = 0x0000;
    can_filter_st.FilterBank = 0;
    can_filter_st.FilterFIFOAssignment = CAN_RX_FIFO0;


    if (HAL_CAN_ConfigFilter(&hcan1, &can_filter_st) != HAL_OK) Error_Handler();
    if (HAL_CAN_Start(&hcan1) != HAL_OK) Error_Handler();

    //开启接收中断，否则 HAL_CAN_RxFifo0MsgPendingCallback 永远不会触发
    if (HAL_CAN_ActivateNotification(&hcan1, CAN_IT_RX_FIFO0_MSG_PENDING) != HAL_OK) Error_Handler();
}

// 2.初始化电机数据
void D3508_Init(void) {
    for(int i=0; i<4; i++) {
        Motors[i].last_angle = 0;
        Motors[i].total_round = 0;
        Motors[i].total_angle = 0;
        Motors[i].target_speed = 0;
        Motors[i].target_angle = 0;
        Motors[i].Out_Current = 0;
        Motors[i].filter_speed = 0.0f;

    }
}

//3.发送控制电流值
void send_current(void){
	CAN_TxHeaderTypeDef TxHeader;
	uint8_t TxData[8];
	uint32_t TxMailbox;

    TxHeader.StdId = 0x200;    // 0x200 控制 ID 1~4 的总指令
    TxHeader.IDE = CAN_ID_STD; //标准帧
    TxHeader.RTR = CAN_RTR_DATA; //数据帧
    TxHeader.DLC = 8;          // 8字节数据

    // 电机1
    TxData[0] = Motors[0].Out_Current >> 8;
    TxData[1] = Motors[0].Out_Current;
    // 电机2
    TxData[2] = Motors[1].Out_Current >> 8;
    TxData[3] = Motors[1].Out_Current;
    // 电机3
    TxData[4] = Motors[2].Out_Current >> 8;
    TxData[5] = Motors[2].Out_Current;
    // 电机4
    TxData[6] = Motors[3].Out_Current >> 8;
    TxData[7] = Motors[3].Out_Current;

    // 发送报文
    HAL_CAN_AddTxMessage(&hcan1, &TxHeader, TxData, &TxMailbox);
}

// 4.速度环 PID 计算
// i: 电机编号(0-3)
void PID_Calc_Speed(int i)
{
	if (i < 0 || i >= 4) return;
    Motor_3508_T* m = &Motors[i];

    // 计算误差
    float error = m->target_speed - m->cur_speed;

    // 积分累加
    m->speed_err_sum += error;
    m->err_last = error;
    // 积分限幅
    if(m->speed_err_sum > Speed_PID.Max_Sum) m->speed_err_sum = Speed_PID.Max_Sum;
    if(m->speed_err_sum < -Speed_PID.Max_Sum) m->speed_err_sum = -Speed_PID.Max_Sum;

    // 计算输出
    float output = (Speed_PID.Kp * error) + (Speed_PID.Ki * m->speed_err_sum * Ts) - (Speed_PID.Kd  * m->filter_speed);

    // 输出限幅
    if(output > Speed_PID.Max_Out) output = Speed_PID.Max_Out;
    if(output < -Speed_PID.Max_Out) output = -Speed_PID.Max_Out;

    //调用功率限制函数
    m->Out_Current = Power_Limit (output, (float)m->filter_speed);

}

// 5.位置环计算函数
// 输入：目标角度 target_angle (单位：总编码器值，8192 = 1圈)
// 输出：写入 Motors[i].target_speed，供速度环使用
void PID_Calc_Position(int i, float target_angle)
{
	if (i < 0 || i >= 4) return;
	Motor_3508_T* m = &Motors[i];

    //  计算位置误差
    // 注意：用 total_angle (多圈累计值) 而不是 cur_angle (0-8192)
	m->target_angle = (int64_t)target_angle;
    float error = m->target_angle - m->total_angle;

    // 死区：对于减速比大的电机，过小的死区会导致末端因机械空程不断抖动
    if (fabs(error) < 25.0f) {
        m->target_speed = 0.0f;
        m->position_err_sum = 0.0f;
        m->Out_Current = 0;
        return;
    }

    // 积分累加
    m->position_err_sum += error;
    m->err_last = error;
    // 积分限幅
    if(m->position_err_sum > Speed_PID.Max_Sum) m->position_err_sum = Speed_PID.Max_Sum;
    if(m->position_err_sum < -Speed_PID.Max_Sum) m->position_err_sum = -Speed_PID.Max_Sum;
    // 位置式 PD 控制
    // 目标速度 = Kp * 位置误差 - Kd * 当前速度
    float position_speed =(Position_PID.Kp * error) + (Speed_PID.Ki * m->position_err_sum * Ts) - (Position_PID.Kd * m->filter_speed);

    // 限幅 (限制最大转速)
    if(position_speed > Position_PID.Max_Out) position_speed = Position_PID.Max_Out;
    if(position_speed < -Position_PID.Max_Out) position_speed = -Position_PID.Max_Out;

    //将计算出的速度 赋值给 速度环的目标
    m->target_speed = position_speed;

    // 调用速度环计算，算出电流
    PID_Calc_Speed(i);
}

// 6.功率限制
int16_t Power_Limit(float desire_current, float rpm){

	// 计算角速度
	float w = fabs(rpm) *2 *3.14f/60;

	if (w < 0.5f) w = 0.5f;

	// 计算最大允许转矩
	float max_torque = POWER_LIMIT / w;

	//计算最大电流
	float max_current_A=max_torque/Kt;

	float max_current_Value=max_current_A *Int_Current;

	//限流
	if (max_current_Value > 16000.0f) max_current_Value = 16000.0f;

	//输出判断
    if (desire_current > max_current_Value) {
        return (int16_t)max_current_Value;
    } else if (desire_current < -max_current_Value) {
        return (int16_t)(-max_current_Value);
    } else {
        return (int16_t)desire_current;
    }

}

// 7.拆解接收数据
void D3508_Decode(uint8_t* RxData, uint16_t ID) {
    // 检查 ID 范围
    if (ID < 0x201 || ID > 0x204) return;

    uint8_t idx = ID - 0x201;
    Motor_3508_T* m = &Motors[idx];

    // 保存上一次角度
    m->last_angle = m->cur_angle;

    // 解析新数据
    m->cur_angle = (RxData[0] << 8) | RxData[1];
    m->cur_speed = (int16_t)((RxData[2] << 8) | RxData[3]);
    m->actual_current = (int16_t)((RxData[4] << 8) | RxData[5]);
    m->temperature = RxData[6];

    //EMA滤波速度
    m->filter_speed = (D3508_EMA_ALPHA * m->cur_speed) + ((1.0f - D3508_EMA_ALPHA) * m->filter_speed);

    //多圈解算
    int32_t delta = (int32_t)m->cur_angle - (int32_t)m->last_angle;
    if (delta > 4096) {
        m->total_round--;
    } else if (delta < -4096) {
        m->total_round++;
    }
    m->total_angle = m->total_round * 8192 + m->cur_angle;
}

/**
 * @brief   [F407版] 接收回调函数
 * @param   hcan      CAN句柄指针
 * @details 当FIFO0中有新消息时，HAL库自动调用此函数
 */
void HAL_CAN_RxFifo0MsgPendingCallback(CAN_HandleTypeDef *hcan)
{
    CAN_RxHeaderTypeDef RxHeader;
    uint8_t RxData[8];

    if(hcan->Instance == CAN1)
    {
        // F407 使用 HAL_CAN_GetRxMessage
        if (HAL_CAN_GetRxMessage(hcan, CAN_RX_FIFO0, &RxHeader, RxData) == HAL_OK)
        {
            // 大疆 3508 ID 范围 (通常为 0x201-0x208)
            if ((RxHeader.StdId >= 0x201) && (RxHeader.StdId <= 0x208))
            {
                D3508_Decode(RxData, (uint16_t)RxHeader.StdId);
            }
            // 达妙电机 ID 范围 (假设你设置为 0x01-0x04)
            else if ((RxHeader.StdId >= 0x01) && (RxHeader.StdId <= 0x04))
            {
                DM_RX_Decode(RxData, (uint16_t)RxHeader.StdId);
            }
        }
    }
}

/**
 * @brief   [F407版] 错误回调函数
 */
void HAL_CAN_ErrorCallback(CAN_HandleTypeDef *hcan)
{
    // F407 的错误处理逻辑
    if (HAL_CAN_GetError(hcan) != HAL_CAN_ERROR_NONE)
    {
        // 可以在此处添加自动恢复逻辑
        // HAL_CAN_ResetError(hcan);
    }
}

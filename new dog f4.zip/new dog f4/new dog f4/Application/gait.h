/**
 * @file gait.h
 * @brief 四足机器人步态控制核心头文件
 * @details 定义四足机器人腿部轨迹生成的相关数据结构、枚举类型和函数声明，
 *          实现摆线拱形前进轨迹和直线后退轨迹的生成，以及四足步态的整体控制。
 * @date 2025-10-26
 * @author ASUS
 */

#ifndef GAIT_H_
#define GAIT_H_

#include <stdint.h>
#include <math.h>
#include "../MIddleware/kinematics.h"

/**
 * @def PI
 * @brief 圆周率常量（单精度浮点型）
 */
#define PI 3.14159265358979323846f

/**
 * @struct Cycloid2D_Pose
 * @brief 2D平面内的摆线轨迹位姿结构体
 * @details 用于描述四足机器人单腿在2D平面（X-Y）的位置坐标，
 *          X轴通常对应机器人前进/后退方向，Y轴对应腿部抬升/下降方向。
 * @var Cycloid2D_Pose::x
 * 	X轴坐标（单位：m，向前为正方向）
 * @var Cycloid2D_Pose::y
 * 	Y轴坐标（单位：m，向上为正方向）
 */
typedef struct {
    float x;  // X轴位置坐标
    float y;  // Y轴位置坐标
} Cycloid2D_Pose;

/**
 * @enum GaitDirection
 * @brief 四足机器人运动方向枚举
 * @details 定义机器人的运动方向，用于控制步态的前进或后退模式。
 * @var GAIT_DIRECTION_FORWARD
 * 前进方向：使用摆线轨迹，初始相位为0
 * @var GAIT_DIRECTION_BACKWARD
 * 后退方向：使用直线轨迹，初始相位为π
 */
typedef enum {
    GAIT_DIRECTION_FORWARD = 0,   // 前进方向
    GAIT_DIRECTION_BACKWARD = 1   // 后退方向
} GaitDirection;

/**
 * @enum GaitPhase
 * @brief 单腿步态相位枚举
 * @details 定义单腿在步态周期内的两种核心运动相位，实现前进和后退的交替运动。
 * @var GAIT_PHASE_CYCLOID_FORWARD
 * 摆线拱形前进相位：腿部抬升并以摆线轨迹向前移动
 * @var GAIT_PHASE_STRAIGHT_BACKWARD
 * 直线后退相位：腿部落地并以直线轨迹向后返回
 */
typedef enum {
    GAIT_PHASE_CYCLOID_FORWARD = 0,   // 摆线前进相位
    GAIT_PHASE_STRAIGHT_BACKWARD = 1  // 直线后退相位
} GaitPhase;

/**
 * @struct LegGaitState
 * @brief 单腿步态状态结构体
 * @details 存储单腿运动的核心参数和状态，用于轨迹生成函数的参数传递和状态维护。
 * @var LegGaitState::x_start
 * 	X轴起始位置（单位：m）
 * @var LegGaitState::x_target
 * 	X轴目标位置（单位：m）
 * @var LegGaitState::y_start
 * 	Y轴起始位置（单位：m）
 * @var LegGaitState::y_target
 * 	Y轴目标位置（单位：m）
 * @var LegGaitState::lift_height
 * 	腿部抬升高度（拱形轨迹最高点，单位：m）
 * @var LegGaitState::cycle_time
 * 	单腿单次运动周期（前进/后退各占半个周期，单位：s）
 * @var LegGaitState::start_time
 * 	当前相位的运动开始时间（系统时间戳，单位：s）
 * @var LegGaitState::phase
 * 	当前步态相位（参考GaitPhase枚举）
 * @var LegGaitState::is_active
 * 	单腿激活状态：1-激活（参与步态运动），0-未激活（保持初始位置）
 */
typedef struct {
    float x_start;       // X轴起始位置
    float x_target;      // X轴目标位置
    float y_start;       // Y轴起始位置
    float y_target;      // Y轴目标位置
    float lift_height;   // 腿部抬升高度
    float cycle_time;    // 单腿运动周期
    float start_time;    // 运动开始时间
    GaitPhase phase;     // 当前步态相位
    uint8_t is_active;   // 单腿激活状态（1-激活，0-未激活）
    LegAngles current_angles; // 逆运动学计算出的电机角度
} LegGaitState;

/**
 * @struct QuadrupedGait
 * @brief 四足机器人整体步态结构体
 * @details 管理四条腿的步态状态，维护全局步态参数，实现四足协同运动。
 * @var QuadrupedGait::legs
 * 	四条腿的步态状态数组（索引0-3分别对应四足的四条腿，如左前、右前、左后、右后）
 * @var QuadrupedGait::gait_cycle_time
 * 	全局步态周期（单腿完成前进+后退的总时间，单位：s）
 * @var QuadrupedGait::stride_length
 * 	步长（单腿前进的X轴位移，单位：m）
 * @var QuadrupedGait::lift_height
 * 	全局腿部抬升高度（所有腿共用，单位：m）
 * @var QuadrupedGait::direction
 * 	运动方向（参考GaitDirection枚举）
 * @var QuadrupedGait::start_time
 * 	全局步态启动时间（系统时间戳，单位：s）
 * @var QuadrupedGait::is_running
 * 	全局步态运行状态：1-运行中，0-已停止
 */
typedef struct {
    LegGaitState legs[4];      // 四条腿的步态状态
    float gait_cycle_time;     // 全局步态周期
    float stride_length;       // 步长
    float lift_height;         // 全局抬升高度
    GaitDirection direction;   // 运动方向
    float start_time;          // 步态启动时间
    uint8_t is_running;        // 全局运行状态（1-运行，0-停止）
} QuadrupedGait;

/**
 * @brief 生成2D摆线拱形轨迹（前进相位）
 * @details 基于摆线公式生成带抬升的拱形轨迹，保证腿部运动的平滑性（速度/加速度连续），
 *          适用于四足机器人腿部抬升前进的阶段。
 * @param t 当前系统时间（单位：s）
 * @param starttime 该轨迹的运动开始时间（单位：s）
 * @param cycle_time 该轨迹的运动周期（单位：s）
 * @param x_start X轴起始位置（单位：m）
 * @param x_target X轴目标位置（单位：m）
 * @param y_start Y轴起始位置（单位：m）
 * @param y_target Y轴目标位置（单位：m）
 * @param lift_height 腿部抬升高度（拱形最高点，单位：m）
 * @return Cycloid2D_Pose 当前时间点的腿部位置坐标
 */
Cycloid2D_Pose cycloid_2d_arch_trajectory(float t,
                                         float starttime,
                                         float cycle_time,
                                         float x_start,
                                         float x_target,
                                         float y_start,
                                         float y_target,
                                         float lift_height);

/**
 * @brief 生成2D直线轨迹（后退相位）
 * @details 生成线性插值的直线轨迹，保证腿部落地后快速、平稳地返回初始位置，
 *          适用于四足机器人腿部落地后退的阶段。
 * @param t 当前系统时间（单位：s）
 * @param starttime 该轨迹的运动开始时间（单位：s）
 * @param cycle_time 该轨迹的运动周期（单位：s）
 * @param x_start X轴起始位置（单位：m）
 * @param x_target X轴目标位置（单位：m）
 * @param y_start Y轴起始位置（单位：m）
 * @param y_target Y轴目标位置（单位：m）
 * @return Cycloid2D_Pose 当前时间点的腿部位置坐标
 */
Cycloid2D_Pose straight_line_trajectory(float t,
                                      float starttime,
                                      float cycle_time,
                                      float x_start,
                                      float x_target,
                                      float y_start,
                                      float y_target);

/**
 * @brief 初始化四足机器人步态结构体
 * @details 清空步态结构体内存，设置全局步态参数（周期、步长、抬升高度、方向），
 *          初始化四条腿的默认状态（未激活、默认相位）。
 * @param gait 指向QuadrupedGait结构体的指针（待初始化的步态结构体）
 * @param cycle_time 全局步态周期（单位：s）
 * @param stride_length 步长（单位：m）
 * @param lift_height 腿部抬升高度（单位：m）
 * @param direction 运动方向（参考GaitDirection枚举）
 * @return 无
 */
void init_quadruped_gait(QuadrupedGait *gait, float cycle_time, float stride_length, float lift_height, GaitDirection direction);

/**
 * @brief 启动四足机器人步态
 * @details 设置全局步态启动时间和运行状态，初始化四条腿的初始相位和运动参数，
 *          实现前两条腿和后两条腿的相位交替（异步运动），保证机器人行走的稳定性。
 * @param gait 指向QuadrupedGait结构体的指针（已初始化的步态结构体）
 * @param current_time 当前系统时间（单位：s）
 * @return 无
 */
void start_quadruped_gait(QuadrupedGait *gait, float current_time);

/**
 * @brief 停止四足机器人步态
 * @details 置位全局运行状态为停止，关闭所有腿部的激活状态，使腿部保持当前位置。
 * @param gait 指向QuadrupedGait结构体的指针（运行中的步态结构体）
 * @return 无
 */
void stop_quadruped_gait(QuadrupedGait *gait);

/**
 * @brief 获取指定腿部的实时轨迹位置
 * @details 根据全局步态周期和腿部索引，判断当前腿部的运动相位，调用对应轨迹生成函数，
 *          返回指定时间点的腿部位置坐标，是步态控制的核心接口函数。
 * @param gait 指向QuadrupedGait结构体的指针（已初始化/运行中的步态结构体）
 * @param leg_index 腿部索引（0-3，对应四条腿）
 * @param current_time 当前系统时间（单位：s）
 * @return Cycloid2D_Pose 指定腿部在当前时间的位置坐标
 */
Cycloid2D_Pose get_leg_trajectory(QuadrupedGait *gait, uint8_t leg_index, float current_time);

/**
 * @brief 获取指定腿部的实时电机角度
 * @details 调用get_leg_trajectory获取腿部位置，然后通过逆运动学计算得到对应的电机角度，
 *          并将计算结果存储到腿部状态中。
 * @param gait 指向QuadrupedGait结构体的指针
 * @param leg_index 腿部索引（0-3）
 * @param current_time 当前系统时间（单位：s）
 * @param angles 指向LegAngles结构体的指针，用于存储计算得到的电机角度
 * @return uint8_t 计算结果：0-成功，1-失败（逆运动学计算出错）
 */
uint8_t get_leg_angles(QuadrupedGait *gait, uint8_t leg_index, float current_time, LegAngles *angles);

#endif /* GAIT_H_ */

/**
 * @file gait.c
 * @brief 四足机器人步态控制核心实现文件
 * @details 实现gait.h中声明的所有函数，包括摆线轨迹、直线轨迹的生成逻辑，
 *          以及四足步态的初始化、启动、停止和实时轨迹计算。
 * @date 2025-10-26
 * @author ASUS
 */

#include "gait.h"
#include <string.h>
#include <math.h>

/**
 * @brief 生成2D摆线拱形轨迹（前进相位）
 * @details 基于摆线运动学公式，生成X轴平滑前进、Y轴带抬升的拱形轨迹：
 *          - X轴：摆线运动（dt - sin(2πdt)/(2π)），保证速度/加速度连续；
 *          - Y轴：线性插值 + 余弦抬升（(1 - cos(2πdt))/2），形成拱形轨迹；
 *          适用于四足机器人腿部抬升前进阶段，避免运动冲击。
 * @param t 当前系统时间（单位：s）
 * @param starttime 该轨迹的运动开始时间（单位：s）
 * @param cycle_time 该轨迹的运动周期（单位：s）
 * @param x_start X轴起始位置（单位：m）
 * @param x_target X轴目标位置（单位：m）
 * @param y_start Y轴起始位置（单位：m）
 * @param y_target Y轴目标位置（单位：m）
 * @param lift_height 腿部抬升高度（拱形最高点，单位：m）
 * @return Cycloid2D_Pose 当前时间点的腿部位置坐标
 * @note 若当前时间早于starttime，返回起始位置；若晚于starttime+cycle_time，返回目标位置；
 *       否则按摆线公式计算实时位置。
 */
Cycloid2D_Pose cycloid_2d_arch_trajectory(float t,
                                         float starttime,
                                         float cycle_time,
                                         float x_start,
                                         float x_target,
                                         float y_start,
                                         float y_target,
                                         float lift_height)
{
    Cycloid2D_Pose current_pose;  // 当前位置坐标
    float error_time = t - starttime;  // 已运动时间（当前时间 - 开始时间）

    // 时间未到：返回起始位置
    if (error_time < 0.0f)
    {
        current_pose.x = x_start;
        current_pose.y = y_start;
        return current_pose;
    }
    // 运动完成：返回目标位置
    else if (error_time >= cycle_time)
    {
        current_pose.x = x_target;
        current_pose.y = y_target;
        return current_pose;
    }

    // 归一化时间（0~1）：将已运动时间映射到周期内的相对时间
    float dt = error_time / cycle_time;
    // X轴位移增量
    float delta_x = x_target - x_start;
    // X轴摆线轨迹计算：摆线公式保证速度从0开始，到0结束（无冲击）
    current_pose.x = x_start + delta_x * (dt - sinf(2.0f * PI * dt) / (2.0f * PI));

    // Y轴位移增量
    float delta_y = y_target - y_start;
    // Y轴拱形轨迹计算：线性插值 + 余弦抬升（形成平滑拱形）
    current_pose.y = y_start + delta_y * dt + lift_height * (1.0f - cosf(2.0f * PI * dt)) / 2.0f;

    return current_pose;
}

/**
 * @brief 生成2D直线轨迹（后退相位）
 * @details 基于线性插值生成直线轨迹，保证腿部落地后快速、平稳返回初始位置，
 *          适用于四足机器人腿部落地后退阶段，简化计算并保证运动效率。
 * @param t 当前系统时间（单位：s）
 * @param starttime 该轨迹的运动开始时间（单位：s）
 * @param cycle_time 该轨迹的运动周期（单位：s）
 * @param x_start X轴起始位置（单位：m）
 * @param x_target X轴目标位置（单位：m）
 * @param y_start Y轴起始位置（单位：m）
 * @param y_target Y轴目标位置（单位：m）
 * @return Cycloid2D_Pose 当前时间点的腿部位置坐标
 * @note 若当前时间早于starttime，返回起始位置；若晚于starttime+cycle_time，返回目标位置；
 *       否则按线性插值计算实时位置。
 */
Cycloid2D_Pose straight_line_trajectory(float t,
                                      float starttime,
                                      float cycle_time,
                                      float x_start,
                                      float x_target,
                                      float y_start,
                                      float y_target)
{
    Cycloid2D_Pose current_pose;  // 当前位置坐标
    float error_time = t - starttime;  // 已运动时间（当前时间 - 开始时间）

    // 时间未到：返回起始位置
    if (error_time < 0.0f)
    {
        current_pose.x = x_start;
        current_pose.y = y_start;
        return current_pose;
    }
    // 运动完成：返回目标位置
    else if (error_time >= cycle_time)
    {
        current_pose.x = x_target;
        current_pose.y = y_target;
        return current_pose;
    }

    // 归一化时间（0~1）：将已运动时间映射到周期内的相对时间
    float dt = error_time / cycle_time;
    // X轴线性插值
    current_pose.x = x_start + (x_target - x_start) * dt;
    // Y轴线性插值
    current_pose.y = y_start + (y_target - y_start) * dt;

    return current_pose;
}

/**
 * @brief 初始化四足机器人步态结构体
 * @details 1. 清空步态结构体所有内存（避免脏数据）；
 *          2. 设置全局步态参数（周期、步长、抬升高度、方向）；
 *          3. 初始化四条腿的默认状态：未激活、摆线前进相位、继承全局抬升高度和周期。
 * @param gait 指向QuadrupedGait结构体的指针（待初始化的步态结构体）
 * @param cycle_time 全局步态周期（单位：s）
 * @param stride_length 步长（单位：m）
 * @param lift_height 腿部抬升高度（单位：m）
 * @param direction 运动方向（参考GaitDirection枚举）
 * @return 无
 * @note 初始化后步态处于停止状态（is_running=0），需调用start_quadruped_gait启动。
 */
void init_quadruped_gait(QuadrupedGait *gait, float cycle_time, float stride_length, float lift_height, GaitDirection direction)
{
    // 清空结构体内存，初始化所有成员为0
    memset(gait, 0, sizeof(QuadrupedGait));
    
    // 设置全局步态参数
    gait->gait_cycle_time = cycle_time;
    gait->stride_length = stride_length;
    gait->lift_height = lift_height;
    gait->direction = direction;  // 设置运动方向
    gait->is_running = 0;  // 默认停止状态
    
    // 初始化四条腿的默认状态
    for (uint8_t i = 0; i < 4; i++)
    {
        gait->legs[i].cycle_time = cycle_time;    // 继承全局周期
        gait->legs[i].lift_height = lift_height;  // 继承全局抬升高度
        gait->legs[i].is_active = 0;              // 默认未激活
        gait->legs[i].phase = GAIT_PHASE_CYCLOID_FORWARD;  // 默认前进相位
    }
}

/**
 * @brief 启动四足机器人步态
 * @details 1. 设置全局步态启动时间和运行状态；
 *          2. 激活所有腿部；
 *          3. 根据方向设置腿部初始相位：
 *             - 前进方向：前两条腿摆线前进（初始相位0），后两条腿直线后退（初始相位π）；
 *             - 后退方向：前两条腿直线后退（初始相位π），后两条腿摆线前进（初始相位0）；
 *          实现四足机器人的对角步态（前腿和后腿异步运动），保证行走稳定性。
 * @param gait 指向QuadrupedGait结构体的指针（已初始化的步态结构体）
 * @param current_time 当前系统时间（单位：s）
 * @return 无
 * @note 启动前需确保已调用init_quadruped_gait完成初始化。
 */
void start_quadruped_gait(QuadrupedGait *gait, float current_time)
{
    // 设置全局启动时间和运行状态
    gait->start_time = current_time;
    gait->is_running = 1;
    
    // 半个步态周期（前进/后退各占一半时间）
    float half_cycle = gait->gait_cycle_time / 2.0f;
    
    // 初始化四条腿的运动参数
    for (uint8_t i = 0; i < 4; i++)
    {
        gait->legs[i].is_active = 1;  // 激活所有腿部
        
        if (gait->direction == GAIT_DIRECTION_FORWARD)
        {
            // 前进方向：前两条腿摆线前进，后两条腿直线后退
            if (i < 2)
            {
                gait->legs[i].phase = GAIT_PHASE_CYCLOID_FORWARD;  // 摆线前进相位（初始相位0）
                gait->legs[i].start_time = current_time;
                gait->legs[i].x_start = 0.0f;
                gait->legs[i].x_target = gait->stride_length;
                gait->legs[i].y_start = 0.0f;
                gait->legs[i].y_target = 0.0f;
            }
            else
            {
                gait->legs[i].phase = GAIT_PHASE_STRAIGHT_BACKWARD;  // 直线后退相位（初始相位π）
                gait->legs[i].start_time = current_time + half_cycle;
                gait->legs[i].x_start = gait->stride_length;
                gait->legs[i].x_target = 0.0f;
                gait->legs[i].y_start = 0.0f;
                gait->legs[i].y_target = 0.0f;
            }
        }
        else
        {
            // 后退方向：前两条腿直线后退，后两条腿摆线前进
            if (i < 2)
            {
                gait->legs[i].phase = GAIT_PHASE_STRAIGHT_BACKWARD;  // 直线后退相位（初始相位π）
                gait->legs[i].start_time = current_time;
                gait->legs[i].x_start = gait->stride_length;
                gait->legs[i].x_target = 0.0f;
                gait->legs[i].y_start = 0.0f;
                gait->legs[i].y_target = 0.0f;
            }
            else
            {
                gait->legs[i].phase = GAIT_PHASE_CYCLOID_FORWARD;  // 摆线前进相位（初始相位0）
                gait->legs[i].start_time = current_time + half_cycle;
                gait->legs[i].x_start = 0.0f;
                gait->legs[i].x_target = gait->stride_length;
                gait->legs[i].y_start = 0.0f;
                gait->legs[i].y_target = 0.0f;
            }
        }
    }
}

/**
 * @brief 停止四足机器人步态
 * @details 1. 置位全局运行状态为停止；
 *          2. 关闭所有腿部的激活状态，使腿部保持当前位置；
 *          停止后调用get_leg_trajectory将返回(0,0)位置。
 * @param gait 指向QuadrupedGait结构体的指针（运行中的步态结构体）
 * @return 无
 */
void stop_quadruped_gait(QuadrupedGait *gait)
{
    gait->is_running = 0;  // 全局停止
    
    // 关闭所有腿部激活状态
    for (uint8_t i = 0; i < 4; i++)
    {
        gait->legs[i].is_active = 0;
    }
}

/**
 * @brief 获取指定腿部的实时轨迹位置
 * @details 核心步态控制接口，逻辑如下：
 *          1. 参数校验：腿部索引越界/步态停止/腿部未激活 → 返回(0,0)；
 *          2. 计算全局已运动时间和当前周期内的相对时间；
 *          3. 根据方向和腿部索引判断当前相位：
 *             - 前进方向：使用摆线轨迹（初始相位0），直线轨迹（初始相位π）；
 *             - 后退方向：使用直线轨迹（初始相位π），摆线轨迹（初始相位0）；
 *          4. 更新腿部当前相位和运动参数，调用对应轨迹函数生成位置。
 * @param gait 指向QuadrupedGait结构体的指针（已初始化/运行中的步态结构体）
 * @param leg_index 腿部索引（0-3，对应四条腿）
 * @param current_time 当前系统时间（单位：s）
 * @return Cycloid2D_Pose 指定腿部在当前时间的位置坐标
 * @note 若参数非法或步态停止，返回(0,0)位置；
 *       周期计数采用整数取模，实现步态的循环运行；
 *       两种轨迹的持续时间相同，均为半个步态周期。
 */
Cycloid2D_Pose get_leg_trajectory(QuadrupedGait *gait, uint8_t leg_index, float current_time)
{
    Cycloid2D_Pose pose = {0.0f, 0.0f};  // 默认返回(0,0)
    
    // 参数校验：索引越界/步态停止/腿部未激活 → 返回默认值
    if (leg_index >= 4 || !gait->is_running || !gait->legs[leg_index].is_active)
    {
        return pose;
    }
    
    LegGaitState *leg = &gait->legs[leg_index];  // 当前腿的状态指针
    float elapsed_time = current_time - gait->start_time;  // 全局已运动时间
    float full_cycle_time = gait->gait_cycle_time;         // 全局步态周期
    float half_cycle_time = full_cycle_time / 2.0f;        // 半个周期时间
    
    // 计算当前处于第几个完整周期（用于循环运动）
    uint32_t cycle_count = (uint32_t)(elapsed_time / full_cycle_time);
    // 计算当前周期内的相对时间（0 ~ full_cycle_time）
    float time_in_cycle = elapsed_time - cycle_count * full_cycle_time;
    
    if (gait->direction == GAIT_DIRECTION_FORWARD)
    {
        // 前进方向：前两条腿摆线前进（初始相位0），后两条腿直线后退（初始相位π）
        if (leg_index < 2)
        {
            if (time_in_cycle < half_cycle_time)
            {
                // 前半周期：摆线前进相位（初始相位0）
                leg->phase = GAIT_PHASE_CYCLOID_FORWARD;
                leg->start_time = gait->start_time + cycle_count * full_cycle_time;
                leg->x_start = 0.0f;
                leg->x_target = gait->stride_length;
                leg->y_start = 0.0f;
                leg->y_target = 0.0f;
                
                // 生成摆线拱形轨迹
                pose = cycloid_2d_arch_trajectory(current_time, leg->start_time, half_cycle_time,
                                                 leg->x_start, leg->x_target,
                                                 leg->y_start, leg->y_target,
                                                 leg->lift_height);
            }
            else
            {
                // 后半周期：直线后退相位（初始相位π）
                leg->phase = GAIT_PHASE_STRAIGHT_BACKWARD;
                leg->start_time = gait->start_time + cycle_count * full_cycle_time + half_cycle_time;
                leg->x_start = gait->stride_length;
                leg->x_target = 0.0f;
                leg->y_start = 0.0f;
                leg->y_target = 0.0f;
                
                // 生成直线轨迹
                pose = straight_line_trajectory(current_time, leg->start_time, half_cycle_time,
                                               leg->x_start, leg->x_target,
                                               leg->y_start, leg->y_target);
            }
        }
        else
        {
            if (time_in_cycle < half_cycle_time)
            {
                // 前半周期：直线后退相位（初始相位π）
                leg->phase = GAIT_PHASE_STRAIGHT_BACKWARD;
                leg->start_time = gait->start_time + cycle_count * full_cycle_time;
                leg->x_start = gait->stride_length;
                leg->x_target = 0.0f;
                leg->y_start = 0.0f;
                leg->y_target = 0.0f;
                
                // 生成直线轨迹
                pose = straight_line_trajectory(current_time, leg->start_time, half_cycle_time,
                                               leg->x_start, leg->x_target,
                                               leg->y_start, leg->y_target);
            }
            else
            {
                // 后半周期：摆线前进相位（初始相位0）
                leg->phase = GAIT_PHASE_CYCLOID_FORWARD;
                leg->start_time = gait->start_time + cycle_count * full_cycle_time + half_cycle_time;
                leg->x_start = 0.0f;
                leg->x_target = gait->stride_length;
                leg->y_start = 0.0f;
                leg->y_target = 0.0f;
                
                // 生成摆线拱形轨迹
                pose = cycloid_2d_arch_trajectory(current_time, leg->start_time, half_cycle_time,
                                                 leg->x_start, leg->x_target,
                                                 leg->y_start, leg->y_target,
                                                 leg->lift_height);
            }
        }
    }
    else
    {
        // 后退方向：前两条腿直线后退（初始相位π），后两条腿摆线前进（初始相位0）
        if (leg_index < 2)
        {
            if (time_in_cycle < half_cycle_time)
            {
                // 前半周期：直线后退相位（初始相位π）
                leg->phase = GAIT_PHASE_STRAIGHT_BACKWARD;
                leg->start_time = gait->start_time + cycle_count * full_cycle_time;
                leg->x_start = gait->stride_length;
                leg->x_target = 0.0f;
                leg->y_start = 0.0f;
                leg->y_target = 0.0f;
                
                // 生成直线轨迹
                pose = straight_line_trajectory(current_time, leg->start_time, half_cycle_time,
                                               leg->x_start, leg->x_target,
                                               leg->y_start, leg->y_target);
            }
            else
            {
                // 后半周期：摆线前进相位（初始相位0）
                leg->phase = GAIT_PHASE_CYCLOID_FORWARD;
                leg->start_time = gait->start_time + cycle_count * full_cycle_time + half_cycle_time;
                leg->x_start = 0.0f;
                leg->x_target = gait->stride_length;
                leg->y_start = 0.0f;
                leg->y_target = 0.0f;
                
                // 生成摆线拱形轨迹
                pose = cycloid_2d_arch_trajectory(current_time, leg->start_time, half_cycle_time,
                                                 leg->x_start, leg->x_target,
                                                 leg->y_start, leg->y_target,
                                                 leg->lift_height);
            }
        }
        else
        {
            if (time_in_cycle < half_cycle_time)
            {
                // 前半周期：摆线前进相位（初始相位0）
                leg->phase = GAIT_PHASE_CYCLOID_FORWARD;
                leg->start_time = gait->start_time + cycle_count * full_cycle_time;
                leg->x_start = 0.0f;
                leg->x_target = gait->stride_length;
                leg->y_start = 0.0f;
                leg->y_target = 0.0f;
                
                // 生成摆线拱形轨迹
                pose = cycloid_2d_arch_trajectory(current_time, leg->start_time, half_cycle_time,
                                                 leg->x_start, leg->x_target,
                                                 leg->y_start, leg->y_target,
                                                 leg->lift_height);
            }
            else
            {
                // 后半周期：直线后退相位（初始相位π）
                leg->phase = GAIT_PHASE_STRAIGHT_BACKWARD;
                leg->start_time = gait->start_time + cycle_count * full_cycle_time + half_cycle_time;
                leg->x_start = gait->stride_length;
                leg->x_target = 0.0f;
                leg->y_start = 0.0f;
                leg->y_target = 0.0f;
                
                // 生成直线轨迹
                pose = straight_line_trajectory(current_time, leg->start_time, half_cycle_time,
                                               leg->x_start, leg->x_target,
                                               leg->y_start, leg->y_target);
            }
        }
    }
    
    return pose;
}

/**
 * @brief 获取指定腿部的实时电机角度
 * @details 调用get_leg_trajectory获取腿部位置，然后通过逆运动学计算得到对应的电机角度，
 *          并将计算结果存储到腿部状态中。
 * @param gait 指向QuadrupedGait结构体的指针
 * @param leg_index 腿部索引（0-3）
 * @param current_time 当前系统时间（单位：s）
 * @param angles 指向LegAngles结构体的指针，用于存储计算得到的电机角度
 * @return uint8_t 计算结果：0-成功，1-失败（逆运动学计算出错）
 * @note 与方向控制完全兼容，根据当前步态方向自动调整角度计算。
 */
uint8_t get_leg_angles(QuadrupedGait *gait, uint8_t leg_index, float current_time, LegAngles *angles)
{
    if (leg_index >= 4 || !gait->is_running || !gait->legs[leg_index].is_active)
    {
        if (angles != NULL)
        {
            angles->theta1 = 0.0f;
            angles->theta2 = 0.0f;
        }
        return 1;
    }
    
    // 获取腿部当前位置（已考虑方向控制）
    Cycloid2D_Pose pose = get_leg_trajectory(gait, leg_index, current_time);
    
    // 使用逆运动学计算电机角度（注意参数顺序：pose.x对应Y，pose.y对应Z）
    uint8_t result = InverseKinematics(pose.x, pose.y, angles);
    
    if (result == 0)
    {
        // 存储计算结果到腿部状态
        gait->legs[leg_index].current_angles = *angles;
    }
    
    return result;
}

#ifndef __KINEMATICS_H__
#define __KINEMATICS_H__

#include "motor_controller.h"
#include "math.h"

#define PI 3.14159265358979323846f
//float sqrt_float(float x) {
//    return sqrtf(x);
//}
//
//double sqrt_double(double x) {
//    return sqrt(x);
//}

typedef struct {
    float theta1;
    float theta2;
} LegAngles;
typedef struct{
	float X ;
	float Y ;
}Currentpos;

uint8_t InverseKinematics(float Y, float Z, LegAngles *angles);
Currentpos ForwardKinematics(MotorData_t*motor_r, MotorData_t*motor_s);

#endif // __KINEMATICS_H__

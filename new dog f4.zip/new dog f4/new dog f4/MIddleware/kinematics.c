#include "kinematics.h"

#include <math.h>
#define PI 3.14159265358979323846f



Currentpos ForwardKinematics(MotorData_t*motor_r, MotorData_t*motor_s) {
	Currentpos currentpos;
	float L1 = 185.0f;

    float L2 = 215.0f;
    float L3 = 0.0f;
    float theta1 = 0.0f;
    float theta2 = 0.0f;
    float theta3 = 0.0f;
    float theta4 = 0.0f;
    float X = 0.0f;
    float Y = 0.0f;

    theta1 = motor_r->last_position - motor_r->Pos;
    theta2 = motor_s->last_position - motor_s->Pos;
    L3 = sqrtf(L1*L1 + L2*L2 + 2.0f*L1*L2*cosf(theta2));
    theta3 = asinf(L2*sinf(theta2)/L3);
    theta4 = theta1 + theta3;
    X = L3*cosf(theta4);
    Y = L3*sinf(theta4);

    motor_r->last_position = motor_r->Pos;
    motor_s->last_position = motor_s->Pos;
    currentpos.X = X;
    currentpos.Y = Y;
    return currentpos;
}

uint8_t InverseKinematics(float Y, float Z, LegAngles *angles) {
    float L1 = 185.0f;
    float L2 = 215.0f;
    float L3 = 0.0f;
    float theta1 = 0.0f;
    float theta2 = 0.0f;
    float theta3 = 0.0f;
    float theta4 = 0.0f;
    float theta5 = 0.0f;

    L3 = sqrtf(Y*Y + Z*Z);

    if(Y > 0 && Z > 0) {
        theta4 = atan2f(Z, Y);
        float cos_theta2 = (L1*L1 + L2*L2 - L3*L3) / (2.0f*L1*L2);
        cos_theta2 = fmaxf(-1.0f, fminf(1.0f, cos_theta2));
        theta2 = acosf(cos_theta2);
        theta3 = asinf(L2*sinf(theta2)/L3);
        theta1 = theta4 - theta3;
    }
    else if(Y < 0 && Z > 0) {
        theta5 = atan2f(Z, Y);
        theta1 = PI/2.0f - theta5;
        float cos_theta2 = (L1*L1 + L2*L2 - L3*L3) / (2.0f*L1*L2);
        cos_theta2 = fmaxf(-1.0f, fminf(1.0f, cos_theta2));
        theta2 = acosf(cos_theta2);
    }
    else {
        return 1;
    }

    if(angles != NULL) {
        angles->theta1 = theta1;
        angles->theta2 = theta2;
    }

    return 0;
}

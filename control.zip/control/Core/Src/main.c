/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body for STM32F103C8T6 Remote Controller
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "spi.h"
#include "gpio.h"
#include <string.h>
#include <stdlib.h>

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
// 遥控器数据结构(按键+摇杆)
typedef struct {
  uint8_t key_state[18]; // KEY1-KEY18状态(0=松开,1=按下)
  uint16_t adc_value[4]; // 摇杆ADC值(LX,LY,RX,RY)
  uint8_t checksum;      // 校验和，用于数据完整性验证
} RemoteData;

// 按键消抖结构体
typedef struct {
  uint8_t current_state;  // 当前状态
  uint8_t last_state;     // 上一次状态
  uint8_t debounce_count; // 消抖计数
} KeyDebounce;

/* NRF24L01相关寄存器定义 */
#define NRF_CONFIG      0x00
#define NRF_EN_AA       0x01
#define NRF_EN_RXADDR   0x02
#define NRF_SETUP_AW    0x03
#define NRF_SETUP_RETR  0x04
#define NRF_RF_CH       0x05
#define NRF_RF_SETUP    0x06
#define NRF_STATUS      0x07
#define NRF_OBSERVE_TX  0x08
#define NRF_RPD         0x09
#define NRF_RX_ADDR_P0  0x0A
#define NRF_TX_ADDR     0x10
#define NRF_RX_PW_P0    0x11
#define NRF_FIFO_STATUS 0x17

/* NRF24L01命令定义 */
#define R_REGISTER      0x00
#define W_REGISTER      0x20
#define R_RX_PAYLOAD    0x61
#define W_TX_PAYLOAD    0xA0
#define FLUSH_TX        0xE1
#define FLUSH_RX        0xE2
#define REUSE_TX_PL     0xE3
#define NOP             0xFF

/* 通信状态定义 */
#define NRF_SEND_SUCCESS 0x00
#define NRF_SEND_TIMEOUT 0x01
#define NRF_SEND_ERROR   0x02

/* 按键消抖参数 */
#define DEBOUNCE_THRESHOLD 2 // 降低消抖阈值以提高灵敏度
#define KEYS_COUNT 18        // 按键数量
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define NRF_CE_PORT     GPIOB
#define NRF_CE_PIN      GPIO_PIN_0
#define NRF_CSN_PORT    GPIOB
#define NRF_CSN_PIN     GPIO_PIN_1
#define MAX_RETRY_COUNT 5
#define TX_TIMEOUT_MS   100
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
#define NRF_CE_HIGH()   HAL_GPIO_WritePin(NRF_CE_PORT, NRF_CE_PIN, GPIO_PIN_SET)
#define NRF_CE_LOW()    HAL_GPIO_WritePin(NRF_CE_PORT, NRF_CE_PIN, GPIO_PIN_RESET)
#define NRF_CSN_HIGH()  HAL_GPIO_WritePin(NRF_CSN_PORT, NRF_CSN_PIN, GPIO_PIN_SET)
#define NRF_CSN_LOW()   HAL_GPIO_WritePin(NRF_CSN_PORT, NRF_CSN_PIN, GPIO_PIN_RESET)
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN PV */
RemoteData tx_data, rx_data;
uint8_t nrf_status = 0;
uint8_t tx_success_count = 0;
uint8_t tx_fail_count = 0;
KeyDebounce keys_debounce[KEYS_COUNT] = {0}; // 按键消抖结构体数组
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
// 按键扫描相关
void Read_Key_State(void);    // 读取按键状态
uint8_t Key_Debounce_Process(uint8_t key_index, uint8_t raw_state); // 按键消抖处理

// ADC相关
void Read_Adc_Value(void);    // 读取ADC值
uint16_t Read_ADC_Channel(uint32_t channel); // 读取单个ADC通道

// NRF24L01相关
void NRF_Init(void);          // 初始化NRF24L01
uint8_t SPI2_WriteReadByte(uint8_t data); // SPI2读写单个字节
void NRF_WriteReg(uint8_t reg, uint8_t value); // 写NRF24L01寄存器
uint8_t NRF_ReadReg(uint8_t reg); // 读NRF24L01寄存器
void NRF_WriteBuf(uint8_t reg, uint8_t *buf, uint8_t len); // 写NRF24L01缓冲区
void NRF_ReadBuf(uint8_t reg, uint8_t *buf, uint8_t len); // 读NRF24L01缓冲区
void NRF_FlushTX(void);       // 清空发送缓冲区
void NRF_FlushRX(void);       // 清空接收缓冲区
uint8_t NRF_Send_Data(RemoteData *data); // 发送数据
uint8_t NRF_Receive_Data(RemoteData *data); // 接收数据
void NRF_SetMode(uint8_t mode); // 设置NRF24L01工作模式(TX/RX)

// 数据处理相关
uint8_t CalculateChecksum(RemoteData *data); // 计算校验和
uint8_t VerifyChecksum(RemoteData *data);    // 验证校验和
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */
  // 初始化数据结构
  memset(&tx_data, 0, sizeof(RemoteData));
  memset(&rx_data, 0, sizeof(RemoteData));
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_ADC1_Init();
  MX_SPI2_Init();
  /* USER CODE BEGIN 2 */
  // 初始化NRF24L01
  NRF_Init();
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
    // 1. 读取按键状态
    Read_Key_State();
    
    // 2. 读取ADC值
    Read_Adc_Value();
    
    // 3. 计算校验和
    tx_data.checksum = CalculateChecksum(&tx_data);
    
    // 4. 发送数据
    if (NRF_Send_Data(&tx_data) == NRF_SEND_SUCCESS)
    {
      tx_success_count++;
    }
    else
    {
      tx_fail_count++;
    }
    
    // 5. 设置为接收模式并尝试接收数据
    NRF_SetMode(1); // 设置为接收模式
    NRF_Receive_Data(&rx_data);
    
    // 6. 短暂延时，控制通信频率
    // 6. 短暂延时，控制通信频率
    HAL_Delay(5); // 200Hz更新频率，提高按键扫描速度
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_ADC;
  PeriphClkInit.AdcClockSelection = RCC_ADCPCLK2_DIV6;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }

  /** Enables the Clock Security System
  */
  HAL_RCC_EnableCSS();
}

/* USER CODE BEGIN 4 */
// 读取按键状态并进行消抖处理
void Read_Key_State(void) {
  // 读取原始按键状态并进行消抖处理
  tx_data.key_state[0]  = Key_Debounce_Process(0, !HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_4));   // KEY1
  tx_data.key_state[1]  = Key_Debounce_Process(1, !HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_8));   // KEY2
  
  // 针对KEY3 (PA10) 进行特殊处理，增加可靠性
  uint8_t key3_raw = 0;
  // 多次读取提高可靠性
  for(int i=0; i<3; i++) {
    key3_raw |= !HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_10);
    HAL_Delay(1); // 短暂延时确保采样间隔
  }
  tx_data.key_state[2] = Key_Debounce_Process(2, key3_raw);  // KEY3
  tx_data.key_state[3]  = Key_Debounce_Process(3, !HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_11));  // KEY4
  tx_data.key_state[4]  = Key_Debounce_Process(4, !HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_12));  // KEY5
  tx_data.key_state[5]  = Key_Debounce_Process(5, !HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_15));  // KEY6
  tx_data.key_state[6]  = Key_Debounce_Process(6, !HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_2));   // KEY7
  tx_data.key_state[7]  = Key_Debounce_Process(7, !HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_3));   // KEY8
  tx_data.key_state[8]  = Key_Debounce_Process(8, !HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_4));   // KEY9
  tx_data.key_state[9]  = Key_Debounce_Process(9, !HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_5));   // KEY10
  tx_data.key_state[10] = Key_Debounce_Process(10, !HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_8));  // KEY11
  tx_data.key_state[11] = Key_Debounce_Process(11, !HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_9));  // KEY12
  tx_data.key_state[12] = Key_Debounce_Process(12, !HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_10)); // KEY13
  tx_data.key_state[13] = Key_Debounce_Process(13, !HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_11)); // KEY14
  tx_data.key_state[14] = Key_Debounce_Process(14, !HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_12)); // KEY15
  tx_data.key_state[15] = Key_Debounce_Process(15, !HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_5));  // KEY16
  tx_data.key_state[16] = Key_Debounce_Process(16, !HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_6));  // KEY17
  tx_data.key_state[17] = Key_Debounce_Process(17, !HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_7));  // KEY18
}

// 按键消抖处理函数
uint8_t Key_Debounce_Process(uint8_t key_index, uint8_t raw_state) {
  // 如果当前状态与上一次状态相同，增加计数
  if (raw_state == keys_debounce[key_index].last_state) {
    if (keys_debounce[key_index].debounce_count < DEBOUNCE_THRESHOLD) {
      keys_debounce[key_index].debounce_count++;
    } else {
      // 如果计数值达到阈值，更新当前状态
      if (keys_debounce[key_index].current_state != raw_state) {
        keys_debounce[key_index].current_state = raw_state;
      }
    }
  } else {
    // 如果状态变化，重置计数
    keys_debounce[key_index].debounce_count = 0;
  }
  
  // 保存当前状态作为下一次的上一次状态
  keys_debounce[key_index].last_state = raw_state;
  
  // 返回消抖后的状态
  return keys_debounce[key_index].current_state;
}

// 将ADC值(0-4095)映射到0-100范围
uint8_t MapAdcToRange(uint16_t adc_value) {
// 线性映射公式：0-4095 -> 0-100
uint32_t mapped_value = (uint32_t)adc_value * 100 / 4095;
// 确保映射后的值在0-100范围内
return (mapped_value > 100) ? 100 : (uint8_t)mapped_value;
}

// 读取ADC值(PA0=LX, PA1=LY, PA2=RX, PA3=RY)并映射到0-100范围
void Read_Adc_Value(void) {
  uint16_t raw_values[4];
  uint16_t mid_value = 2048; // 12位ADC的中间值
  uint16_t min_threshold = 100; // 阈值，当变化小于此值时视为未操作
  
  // 读取原始ADC值
  raw_values[0] = Read_ADC_Channel(ADC_CHANNEL_0); // 通道0 (PA0-LX)
  raw_values[1] = Read_ADC_Channel(ADC_CHANNEL_1); // 通道1 (PA1-LY)
  raw_values[2] = Read_ADC_Channel(ADC_CHANNEL_2); // 通道2 (PA2-RX)
  raw_values[3] = Read_ADC_Channel(ADC_CHANNEL_3); // 通道3 (PA3-RY)
  
  // 处理ADC值：如果变化很小，设为中间值，确保初始状态一致，然后映射到0-100范围
  for (int i = 0; i < 4; i++) {
    uint16_t processed_value;
    
    // 计算与中间值的差值
    int32_t diff = abs((int32_t)raw_values[i] - (int32_t)mid_value);
    
    // 如果差值小于阈值，视为未操作，设为中间值
    if (diff < min_threshold) {
      processed_value = mid_value;
    } else {
      // 否则使用实际读取的值
      processed_value = raw_values[i];
    }
    
    // 将处理后的值映射到0-100范围
    tx_data.adc_value[i] = MapAdcToRange(processed_value);
  }
}

// 读取单个ADC通道的值
uint16_t Read_ADC_Channel(uint32_t channel) {
  ADC_ChannelConfTypeDef sConfig = {0};
  uint16_t adc_value = 0;
  
  // 配置指定通道
  sConfig.Channel = channel;
  sConfig.Rank = 1;
  sConfig.SamplingTime = ADC_SAMPLETIME_239CYCLES_5;
  
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK) {
    Error_Handler();
  }
  
  // 启动ADC并进行转换
  if (HAL_ADC_Start(&hadc1) != HAL_OK) {
    Error_Handler();
  }
  
  // 等待转换完成
  if (HAL_ADC_PollForConversion(&hadc1, 100) == HAL_OK) {
    // 读取ADC值
    adc_value = HAL_ADC_GetValue(&hadc1);
  }
  
  // 停止ADC
  HAL_ADC_Stop(&hadc1);
  
  return adc_value;
}

// 初始化NRF24L01
void NRF_Init(void) {
  // 初始化CE和CSN引脚
  NRF_CE_LOW();    // CE=0，待机模式
  NRF_CSN_HIGH();  // CSN=1，SPI不工作
  HAL_Delay(100);  // 等待模块稳定
  
  // 清空缓冲区
  NRF_FlushTX();
  NRF_FlushRX();
  
  // 配置基本参数
  NRF_WriteReg(NRF_CONFIG, 0x08);  // 电源开启，接收模式
  NRF_WriteReg(NRF_EN_AA, 0x01);   // 启用频道0的自动确认
  NRF_WriteReg(NRF_EN_RXADDR, 0x01); // 启用接收地址0
  NRF_WriteReg(NRF_SETUP_AW, 0x03);  // 设置地址宽度为5字节
  NRF_WriteReg(NRF_SETUP_RETR, 0x1A); // 自动重发间隔500us，最多重发10次
  NRF_WriteReg(NRF_RF_CH, 0x02);     // 设置RF通道为2
  NRF_WriteReg(NRF_RF_SETUP, 0x07);  // 发射功率0dBm，速率2Mbps
  
  // 设置接收和发送地址
  uint8_t tx_addr[5] = {0xE7, 0xE7, 0xE7, 0xE7, 0xE7};
  NRF_WriteBuf(NRF_TX_ADDR, tx_addr, 5);
  NRF_WriteBuf(NRF_RX_ADDR_P0, tx_addr, 5); // 接收地址0与发送地址相同，用于自动确认
  
  // 设置接收数据宽度
  NRF_WriteReg(NRF_RX_PW_P0, sizeof(RemoteData));
  
  // 清除中断标志
  nrf_status = NRF_ReadReg(NRF_STATUS);
  NRF_WriteReg(NRF_STATUS, nrf_status | 0x70); // 清除TX_DS, RX_DR, MAX_RT中断标志
}

// SPI2读写单个字节
uint8_t SPI2_WriteReadByte(uint8_t data) {
  uint8_t rx_data;
  HAL_SPI_TransmitReceive(&hspi2, &data, &rx_data, 1, 100);
  return rx_data;
}

// 写NRF24L01寄存器
void NRF_WriteReg(uint8_t reg, uint8_t value) {
  NRF_CSN_LOW();
  SPI2_WriteReadByte(W_REGISTER | reg); // 发送写寄存器命令
  SPI2_WriteReadByte(value);            // 发送数据
  NRF_CSN_HIGH();
}

// 读NRF24L01寄存器
uint8_t NRF_ReadReg(uint8_t reg) {
  uint8_t value;
  NRF_CSN_LOW();
  SPI2_WriteReadByte(R_REGISTER | reg); // 发送读寄存器命令
  value = SPI2_WriteReadByte(NOP);      // 读取数据
  NRF_CSN_HIGH();
  return value;
}

// 写NRF24L01缓冲区
void NRF_WriteBuf(uint8_t reg, uint8_t *buf, uint8_t len) {
  uint8_t i;
  NRF_CSN_LOW();
  SPI2_WriteReadByte(reg); // 发送命令
  for(i = 0; i < len; i++) {
    SPI2_WriteReadByte(buf[i]); // 依次写入数据
  }
  NRF_CSN_HIGH();
}

// 读NRF24L01缓冲区
void NRF_ReadBuf(uint8_t reg, uint8_t *buf, uint8_t len) {
  uint8_t i;
  NRF_CSN_LOW();
  SPI2_WriteReadByte(reg); // 发送命令
  for(i = 0; i < len; i++) {
    buf[i] = SPI2_WriteReadByte(NOP); // 依次读取数据
  }
  NRF_CSN_HIGH();
}

// 清空发送缓冲区
void NRF_FlushTX(void) {
  NRF_CSN_LOW();
  SPI2_WriteReadByte(FLUSH_TX);
  NRF_CSN_HIGH();
}

// 清空接收缓冲区
void NRF_FlushRX(void) {
  NRF_CSN_LOW();
  SPI2_WriteReadByte(FLUSH_RX);
  NRF_CSN_HIGH();
}

// 设置NRF24L01工作模式
void NRF_SetMode(uint8_t mode) {
  if(mode == 0) { // 发送模式
    NRF_CE_LOW();
    NRF_WriteReg(NRF_CONFIG, 0x0E); // 电源开启，发送模式
    HAL_Delay(1);
  } else { // 接收模式
    NRF_CE_LOW();
    NRF_WriteReg(NRF_CONFIG, 0x0F); // 电源开启，接收模式，使能中断
    HAL_Delay(1);
    NRF_CE_HIGH(); // 拉高CE，进入接收状态
    HAL_Delay(130); // 等待RX模式稳定
  }
}

// 发送数据
uint8_t NRF_Send_Data(RemoteData *data) {
  uint8_t retry = 0;
  uint8_t status;
  
  // 切换到发送模式
  NRF_SetMode(0);
  
  // 清空TX缓冲区
  NRF_FlushTX();
  
  // 发送数据
  NRF_WriteBuf(W_TX_PAYLOAD, (uint8_t*)data, sizeof(RemoteData));
  
  // 发送数据包
  NRF_CE_HIGH();
  HAL_Delay(1);
  NRF_CE_LOW();
  
  // 等待发送完成或超时
  uint32_t start_time = HAL_GetTick();
  while(1) {
    status = NRF_ReadReg(NRF_STATUS);
    if(status & 0x20) { // TX_DS = 1，发送成功
      NRF_WriteReg(NRF_STATUS, 0x20); // 清除TX_DS标志
      return NRF_SEND_SUCCESS;
    }
    if(status & 0x10) { // MAX_RT = 1，达到最大重发次数
      NRF_WriteReg(NRF_STATUS, 0x10); // 清除MAX_RT标志
      NRF_FlushTX(); // 清空TX缓冲区
      retry++;
      if(retry > MAX_RETRY_COUNT) {
        return NRF_SEND_ERROR;
      }
      // 重新发送
      NRF_WriteBuf(W_TX_PAYLOAD, (uint8_t*)data, sizeof(RemoteData));
      NRF_CE_HIGH();
      HAL_Delay(1);
      NRF_CE_LOW();
    }
    // 检查超时
    if((HAL_GetTick() - start_time) > TX_TIMEOUT_MS) {
      return NRF_SEND_TIMEOUT;
    }
  }
}

// 接收数据
uint8_t NRF_Receive_Data(RemoteData *data) {
  uint8_t status = NRF_ReadReg(NRF_STATUS);
  
  if(status & 0x40) { // RX_DR = 1，收到数据
    NRF_ReadBuf(R_RX_PAYLOAD, (uint8_t*)data, sizeof(RemoteData)); // 读取数据
    NRF_WriteReg(NRF_STATUS, 0x40); // 清除RX_DR标志
    
    // 验证校验和
    if(VerifyChecksum(data)) {
      return 1; // 数据有效
    } else {
      return 0; // 数据无效
    }
  }
  
  return 0; // 没有收到数据
}

// 计算校验和
uint8_t CalculateChecksum(RemoteData *data) {
  uint8_t checksum = 0;
  uint8_t *ptr = (uint8_t*)data;
  uint16_t len = sizeof(RemoteData) - 1; // 不包括checksum字段本身
  
  for(uint16_t i = 0; i < len; i++) {
    checksum ^= ptr[i]; // 简单的异或校验
  }
  
  return checksum;
}

// 验证校验和
uint8_t VerifyChecksum(RemoteData *data) {
  uint8_t calculated_checksum = CalculateChecksum(data);
  return (calculated_checksum == data->checksum);
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
    // 可以在这里添加LED闪烁或其他错误指示
    HAL_Delay(200);
    HAL_Delay(200);
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
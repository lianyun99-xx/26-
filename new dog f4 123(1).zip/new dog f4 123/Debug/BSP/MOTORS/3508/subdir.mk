################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../BSP/MOTORS/3508/3508_driver.c 

OBJS += \
./BSP/MOTORS/3508/3508_driver.o 

C_DEPS += \
./BSP/MOTORS/3508/3508_driver.d 


# Each subdirectory must supply rules for building sources it contributes
BSP/MOTORS/3508/%.o BSP/MOTORS/3508/%.su BSP/MOTORS/3508/%.cyclo: ../BSP/MOTORS/3508/%.c BSP/MOTORS/3508/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F407xx -c -I../Core/Inc -I"C:/Users/nianyun/STM32CubeIDE/workspace_1.19.0/new dog f4 123/new dog f4   123/new dog f4 123/BSP/MOTORS/8010" -I"C:/Users/nianyun/STM32CubeIDE/workspace_1.19.0/new dog f4 123/new dog f4   123/new dog f4 123/BSP/MOTORS/3508" -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -I../BSP/MOTORS/8010 -I../BSP/MOTORS/dm -I../BSP/MOTORS/3508 -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-BSP-2f-MOTORS-2f-3508

clean-BSP-2f-MOTORS-2f-3508:
	-$(RM) ./BSP/MOTORS/3508/3508_driver.cyclo ./BSP/MOTORS/3508/3508_driver.d ./BSP/MOTORS/3508/3508_driver.o ./BSP/MOTORS/3508/3508_driver.su

.PHONY: clean-BSP-2f-MOTORS-2f-3508


################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../BSP/MOTORS/8010/Kalman.c \
../BSP/MOTORS/8010/crc_ccitt.c \
../BSP/MOTORS/8010/delay.c \
../BSP/MOTORS/8010/gom_protocol.c \
../BSP/MOTORS/8010/motor_controller.c 

OBJS += \
./BSP/MOTORS/8010/Kalman.o \
./BSP/MOTORS/8010/crc_ccitt.o \
./BSP/MOTORS/8010/delay.o \
./BSP/MOTORS/8010/gom_protocol.o \
./BSP/MOTORS/8010/motor_controller.o 

C_DEPS += \
./BSP/MOTORS/8010/Kalman.d \
./BSP/MOTORS/8010/crc_ccitt.d \
./BSP/MOTORS/8010/delay.d \
./BSP/MOTORS/8010/gom_protocol.d \
./BSP/MOTORS/8010/motor_controller.d 


# Each subdirectory must supply rules for building sources it contributes
BSP/MOTORS/8010/%.o BSP/MOTORS/8010/%.su BSP/MOTORS/8010/%.cyclo: ../BSP/MOTORS/8010/%.c BSP/MOTORS/8010/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F407xx -c -I../Core/Inc -I"C:/Users/nianyun/STM32CubeIDE/workspace_1.19.0/new dog f4 123/new dog f4   123/new dog f4 123/BSP/MOTORS/8010" -I"C:/Users/nianyun/STM32CubeIDE/workspace_1.19.0/new dog f4 123/new dog f4   123/new dog f4 123/BSP/MOTORS/3508" -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -I../BSP/MOTORS/8010 -I../BSP/MOTORS/dm -I../BSP/MOTORS/3508 -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-BSP-2f-MOTORS-2f-8010

clean-BSP-2f-MOTORS-2f-8010:
	-$(RM) ./BSP/MOTORS/8010/Kalman.cyclo ./BSP/MOTORS/8010/Kalman.d ./BSP/MOTORS/8010/Kalman.o ./BSP/MOTORS/8010/Kalman.su ./BSP/MOTORS/8010/crc_ccitt.cyclo ./BSP/MOTORS/8010/crc_ccitt.d ./BSP/MOTORS/8010/crc_ccitt.o ./BSP/MOTORS/8010/crc_ccitt.su ./BSP/MOTORS/8010/delay.cyclo ./BSP/MOTORS/8010/delay.d ./BSP/MOTORS/8010/delay.o ./BSP/MOTORS/8010/delay.su ./BSP/MOTORS/8010/gom_protocol.cyclo ./BSP/MOTORS/8010/gom_protocol.d ./BSP/MOTORS/8010/gom_protocol.o ./BSP/MOTORS/8010/gom_protocol.su ./BSP/MOTORS/8010/motor_controller.cyclo ./BSP/MOTORS/8010/motor_controller.d ./BSP/MOTORS/8010/motor_controller.o ./BSP/MOTORS/8010/motor_controller.su

.PHONY: clean-BSP-2f-MOTORS-2f-8010


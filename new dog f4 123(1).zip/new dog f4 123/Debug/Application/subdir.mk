################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Application/gait.c 

OBJS += \
./Application/gait.o 

C_DEPS += \
./Application/gait.d 


# Each subdirectory must supply rules for building sources it contributes
Application/%.o Application/%.su Application/%.cyclo: ../Application/%.c Application/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F407xx -c -I../Core/Inc -I"C:/Users/nianyun/STM32CubeIDE/workspace_1.19.0/new dog f4 123/new dog f4   123/new dog f4 123/BSP/MOTORS/8010" -I"C:/Users/nianyun/STM32CubeIDE/workspace_1.19.0/new dog f4 123/new dog f4   123/new dog f4 123/BSP/MOTORS/3508" -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -I../BSP/MOTORS/8010 -I../BSP/MOTORS/dm -I../BSP/MOTORS/3508 -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Application

clean-Application:
	-$(RM) ./Application/gait.cyclo ./Application/gait.d ./Application/gait.o ./Application/gait.su

.PHONY: clean-Application


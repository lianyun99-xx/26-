#include "kinematics.h"
#include <math.h>
//#define PI 3.141f
static float pos_offset_s = 0.0f;
static float pos_offset_r = 0.0f;
static uint8_t is_calibrated = 1;
Currentpos ForwardKinematics(MotorController *ctrl) {
    MotorData_t *motor_s = &ctrl->datas[1]; // 大腿电机
    MotorData_t *motor_r = &ctrl->datas[5]; // 小腿电机
    Currentpos currentpos = {0.0f, 0.0f};

    float L1 = 18.50f;
    float L2 = 21.50f;
    float theta1 = 0.0f;
    float theta2 = 0.0f;
    float X = 0.0f;
    float Y = 0.0f;
    if (is_calibrated) {
        if (fabsf(motor_s->Pos) > 0.001f || fabsf(motor_r->Pos) > 0.001f) {
            pos_offset_s = motor_s->Pos;
            pos_offset_r = motor_r->Pos;
            is_calibrated = 0;
        } else {
            // 如果数据还没准备好，直接返回全 0，不进行后续计算
            return currentpos;
        }
    }
    theta2=motor_r->Pos/6.33-pos_offset_r/6.33;
//    theta1=motor_s->Pos/6.33-pos_offset_s/6.33;
    theta1=pos_offset_s/6.33-motor_s->Pos/6.33;
    X= L1*sinf(theta1)+L2*sinf(theta2+theta1+0.215*M_PI);
//    if(X>0){
    Y= L1*cosf(theta1)+L2*cosf(theta2+theta1+0.215*M_PI);
//    }else{
//    	Y= L1*cosf(theta1)+L2*cosf(theta1+0.215*M_PI);
//    }
    currentpos.X = X;
    currentpos.Y = Y;
    return currentpos;
}
LegAngles  InverseKinematics(float X, float Y ,MotorController* ctrl,int hip_id,int calf_id) {
    float L1 = 18.5f;
    float L2 = 21.5f;
    float L3 = 0.0f;
    float theta1 = 0.0f;
    float theta2 = 0.0f;
    float theta3 = 0.0f;
    float theta4 = 0.0f;
    LegAngles angles;
    L3 = sqrtf(X*X + Y*Y);
    float cos_val1=(L3*L3-L1*L1-L2*L2)/2/L1/L2;
    if (cos_val1 > 1.0f) cos_val1 = 1.0f;
    if (cos_val1 < -1.0f) cos_val1 = -1.0f;
    theta2=acosf(cos_val1);
    theta3=atan2f(Y,X);
    float cos_val2=(L3*L3+L1*L1-L2*L2)/2/L1/L3;
    if (cos_val2 > 1.0f) cos_val2 = 1.0f;
    if (cos_val2 < -1.0f) cos_val2 = -1.0f;
    theta4=acosf(cos_val2);
    if(Y > 0 && X > 0) {
    	theta1=3.14/2-(theta3+theta4);
    }else if(Y > 0 && X < 0) {

    theta1=theta4-(M_PI/2-theta3+M_PI);
    }
        angles.theta1 = -(theta1*6.33+pos_offset_s);
        angles.theta2 = (theta2*6.33+pos_offset_r);
        MotorController_SetCommand(ctrl, calf_id, 1, 0.0, 0.0f, angles.theta2-2.5, 0.2, 0.1);
        MotorController_SetCommand(ctrl, hip_id, 1, 0.0, 0.0f, angles.theta1+3.2, 0.2, 0.1);
 return angles;
}

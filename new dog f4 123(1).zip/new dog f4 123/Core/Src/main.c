/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file           : main.c
 * @brief          : Main program body
 ******************************************************************************
 * @attention
 *
 * Copyright (c) 2026 STMicroelectronics.
 * All rights reserved.
 *
 * This software is licensed under terms that can be found in the LICENSE file
 * in the root directory of this software component.
 * If no LICENSE file comes with this software, it is provided AS-IS.
 *
 ******************************************************************************
 */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "can.h"
#include "dma.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "gom_protocol.h"
#include <string.h>
#include "motor_controller.h"
#include "rs485.h"
#include <stdio.h>
#include "3508_driver.h"
#include "../../MIddleware/kinematics.h"
#include "../../Application/gait.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
Currentpos currentpos;
LegAngles angles;
QuadrupedGait gait;
extern CAN_HandleTypeDef hcan1;
extern Motor_3508_T Motors[4];
MotorController ctrl1;
MotorController ctrl2;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  /* USER CODE BEGIN Callback 0 */
	if (htim->Instance == TIM3) {
	        static uint8_t step = 0;
	        switch(step) {
	            case 0:
	                MotorController_SendCommand2(&ctrl2, 1);
	                step = 1;
	                break;
	            case 1:
	                MotorController_SendCommand2(&ctrl2, 5);
	                step = 0;
//	                break;
//	            case 2:
//	                MotorController_SendCommand2(&ctrl2, 1);
//	                step = 3;
//	                break;
//	            case 3:
//	                MotorController_SendCommand2(&ctrl2, 5);
//	                step = 0 ;
//	                break;
	        }
	    }

}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_TIM3_Init();
  MX_USART1_UART_Init();
  MX_USART6_UART_Init();
  MX_CAN1_Init();
  /* USER CODE BEGIN 2 */
    CAN_Filter_Init();
    D3508_Init();
    Motors[0].target_speed=-1500.0f;
//    MotorController_Init(&ctrl1, &huart1, RS485_REDE2_GPIO_Port, RS485_REDE2_Pin);
    MotorController_Init(&ctrl2, &huart6, RS485_REDE2_GPIO_Port, RS485_REDE2_Pin);

//    MotorController_SetCommand(&ctrl2, 1, 1, 0.0, 0.0f, 0.0, 0, 0);
//    MotorController_SetCommand(&ctrl2, 4, 1, 0.0, 0.0f, 0.0, 0, 0);
//    MotorController_SetCommand(&ctrl2, 5, 1, 0.0, 0.0f, 0.0, 0, 0);

    uint32_t startTime=HAL_GetTick()/1000;
    init_quadruped_gait(&gait, 1.0f, 20.0f, 8.4f, 1);
    HAL_TIM_Base_Start_IT(&htim3);
    HAL_Delay(50);
    for (uint8_t i = 0; i < 4; i++) {
        calibrate_leg_base_position(&gait, i, &ctrl2);
    }
    start_quadruped_gait(&gait,startTime);

    // 【修改】：新增 last_kinematics_tick 供运动学独立时间调度
    uint32_t last_tick = HAL_GetTick();
    uint32_t last_kinematics_tick = HAL_GetTick();
    HAL_Delay(20);

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
	  uint32_t now = HAL_GetTick();

	  // 【修改】：1. 高频电机控制任务 (4ms 周期)
	  if(now - last_tick >= 4)
	  {
	      last_tick = now;

	      //计算 PID
//	           for(int i = 0; i < 4; i++) {
//	               PID_Calc_Position(i,Motors[i].target_angle);
//	           }

//	      float motor_angle=720.0f;
//	      Motors[0].target_angle = (int64_t)(motor_angle * 19.0f * 8192.0f / 360.0f);
//	      PID_Calc_Position(0, Motors[0].target_angle);
		  PID_Calc_Speed(0);

	      // 发送电流
	      send_current();
	  }

	  // 【修改】：2. 低频运动学解算调度 (20ms 周期，完全非阻塞)
	  if(now - last_kinematics_tick >= 20)
	  {
	      last_kinematics_tick = now;

	      currentpos = ForwardKinematics(&ctrl2);
	      float currentTimeSec = now / 1000.0f;
	      angles = get_leg_angles(&gait, 1, currentTimeSec, &ctrl2, 1, 5);
	  }

	  // 【修改】：彻底删除了此处的 HAL_Delay(20); 让主循环能够全速扫描

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 168;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();





  }
}

/* USER CODE BEGIN 4 */
void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart) {
    if(huart == &huart1) {
        RS485_RxMode1();
        HAL_UART_Receive_DMA(ctrl1.uart,
                            (uint8_t*)&ctrl1.datas[ctrl1.last_sent_motor_id].motor_recv_data,
                             sizeof(ctrl1.datas[ctrl1.last_sent_motor_id].motor_recv_data));

    }
    if(huart == &huart6) {
        RS485_RxMode2();
        HAL_UART_Receive_DMA(ctrl2.uart,
                            (uint8_t*)&ctrl2.datas[ctrl2.last_sent_motor_id].motor_recv_data,
                             sizeof(ctrl2.datas[ctrl2.last_sent_motor_id].motor_recv_data));

    }
}
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart) {
    if (huart == &huart1) {
    	extract_data(&ctrl1.datas[ctrl1.last_sent_motor_id]); // 处理数据
    	ctrl1.dma_busy = 0;
    }
    if (huart == &huart6) {
    	extract_data(&ctrl2.datas[ctrl2.last_sent_motor_id]); // 处理数据
    	ctrl2.dma_busy = 0;
    }
}


/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  * where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

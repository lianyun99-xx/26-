#include "gait.h"
#include <string.h>
#include <math.h>

#ifndef PI
#define PI 3.14159265358979323846f
#endif

/* 电机物理/软限位定义 */
#define MOTOR_HIP_MAX   150.0f
#define MOTOR_HIP_MIN   -150.0f
#define MOTOR_KNEE_MAX  160.0f
#define MOTOR_KNEE_MIN  5.0f

/**
 * @brief 角度限位保护
 */
static float clamp_angle(float angle, float min_val, float max_val) {
    if (isnan(angle)) return 0.0f;
    if (angle > max_val) return max_val;
    if (angle < min_val) return min_val;
    return angle;
}

/**
 * @brief 初始化步态参数
 */
void init_quadruped_gait(QuadrupedGait *gait, float cycle_time, float stride_length, float lift_height, GaitDirection direction)
{
    memset(gait, 0, sizeof(QuadrupedGait));
    gait->gait_cycle_time = cycle_time;
    gait->stride_length = stride_length;
    gait->lift_height = lift_height;
    gait->direction = direction;
    gait->is_running = 0;

    for (uint8_t i = 0; i < 4; i++) {
        gait->legs[i].x_base = 0;
        gait->legs[i].y_base = 0;
    }
}

/**
 * @brief 校准基准位置
 */
void calibrate_leg_base_position(QuadrupedGait *gait, uint8_t leg_index, MotorController *ctrl)
{
    if (leg_index >= 4) return;
    Currentpos pos = ForwardKinematics(ctrl);
    gait->legs[leg_index].x_base = pos.X;
    gait->legs[leg_index].y_base = pos.Y;
}

/**
 * @brief 核心摆线轨迹生成（Y向下为正版本）
 * 修正：抬腿时 Y 减小
 */
Cycloid2D_Pose calculate_cycloid_step(float dt, float x_start, float x_end, float y_base, float lift_height, uint8_t is_swing)
{
    Cycloid2D_Pose pose;

    if (dt < 0.0f) dt = 0.0f;
    if (dt > 1.0f) dt = 1.0f;

    if (is_swing) {
        // 摆动相：X 轴标准摆线
        float phase = 2.0f * PI * dt;
        pose.x = x_start + (x_end - x_start) * (dt - sinf(phase) / (2.0f * PI));
        // Y 轴抬升：在 Y 向下为正的坐标系中，抬腿意味着 Y 坐标变小 (减去 lift_height)
        pose.y = y_base - lift_height * 0.5f * (1.0f - cosf(phase));
    } else {
        // 支撑相：平滑线性
        float smooth_dt = dt - sinf(2.0f * PI * dt) / (2.0f * PI);
        pose.x = x_start + (x_end - x_start) * smooth_dt;
        pose.y = y_base;
    }

    return pose;
}

/**
 * @brief 获取当前腿的轨迹点
 */
Cycloid2D_Pose get_leg_trajectory(QuadrupedGait *gait, uint8_t leg_index, float current_time)
{
    LegGaitState *leg = &gait->legs[leg_index];
    if (!gait->is_running) return (Cycloid2D_Pose){leg->x_base, leg->y_base};

    float T = gait->gait_cycle_time;
    float half_T = T / 2.0f;
    float elapsed_time = current_time - gait->start_time;

    uint32_t cycle_count = (uint32_t)(elapsed_time / T);
    float t_rel = elapsed_time - (cycle_count * T);

    float half_S = gait->stride_length / 2.0f;
    float x_back  = leg->x_base - half_S;
    float x_front = leg->x_base + half_S;

    float swing_x_start, swing_x_end;
    if (gait->direction == GAIT_DIRECTION_FORWARD) {
        swing_x_start = x_back;
        swing_x_end   = x_front;
    } else {
        swing_x_start = x_front;
        swing_x_end   = x_back;
    }

    uint8_t is_group_a = (leg_index == 0 || leg_index == 3);
    float dt;
    uint8_t phase_is_swing;
    float current_x_start, current_x_end;

    if (is_group_a) {
        if (t_rel < half_T) {
            phase_is_swing = 1;
            dt = t_rel / half_T;
            current_x_start = (cycle_count == 0) ? leg->x_base : swing_x_start;
            current_x_end = swing_x_end;
        } else {
            phase_is_swing = 0;
            dt = (t_rel - half_T) / half_T;
            current_x_start = swing_x_end;
            current_x_end = swing_x_start;
        }
    } else {
        if (t_rel < half_T) {
            phase_is_swing = 0;
            dt = t_rel / half_T;
            current_x_start = (cycle_count == 0) ? leg->x_base : swing_x_end;
            current_x_end = swing_x_start;
        } else {
            phase_is_swing = 1;
            dt = (t_rel - half_T) / half_T;
            current_x_start = swing_x_start;
            current_x_end = swing_x_end;
        }
    }

    return calculate_cycloid_step(dt, current_x_start, current_x_end, leg->y_base, gait->lift_height, phase_is_swing);
}

/**
 * @brief 角度解算（含坐标系适配）
 */
LegAngles get_leg_angles(QuadrupedGait *gait, uint8_t leg_index, float current_time, MotorController* ctrl, int hip_id, int calf_id)
{
    Cycloid2D_Pose pose = get_leg_trajectory(gait, leg_index, current_time);

    // 盲区保护：在 Y 向下为正时，如果 Y 太小（接近 0 或负数），说明足端离身体太近
    // 假设正常站立 Y 约为 100，抬腿后 Y 变为 70
    // 如果 pose.y 小于某个阈值，强制限制，防止逆运动学无解
    if (pose.y < 20.0f) pose.y = 20.0f;

    LegAngles result = InverseKinematics(pose.x, pose.y, ctrl, hip_id, calf_id);

    result.theta1 = clamp_angle(result.theta1, MOTOR_HIP_MIN, MOTOR_HIP_MAX);
    result.theta2 = clamp_angle(result.theta2, MOTOR_KNEE_MIN, MOTOR_KNEE_MAX);

    gait->legs[leg_index].current_angles = result;
    return result;
}

void start_quadruped_gait(QuadrupedGait *gait, float current_time)
{
    gait->start_time = current_time;
    gait->is_running = 1;
}

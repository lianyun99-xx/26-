#include "motor_controller.h"
#include <string.h>
#include "rs485.h"
/**
  * @brief 初始化电机控制器
  */
void MotorController_Init(MotorController* ctrl,
                         UART_HandleTypeDef* uart,
                         GPIO_TypeDef* de_port,
                         uint16_t de_pin) {
    // 初始化硬件参数
    ctrl->uart = uart;
    ctrl->de_port = de_port;
    ctrl->de_pin = de_pin;


    // 初始化所有电机指令
    for (uint8_t i = 0; i < MOTOR_NUM; i++) {
        ctrl->cmds[i].id = i;     // ID从0开始
        ctrl->cmds[i].mode = 1;       // 默认阻尼模式
        ctrl->cmds[i].T = 0.0f;       // 扭矩
        ctrl->cmds[i].W = 0.0f;       // 速度
        ctrl->cmds[i].Pos = 0.0f;     // 位置
        ctrl->cmds[i].K_P = 0.0f;     // 刚度
        ctrl->cmds[i].K_W = 0.0f;     // 阻尼

        modify_data(&ctrl->cmds[i]); // 生成协议数据

        memset(&ctrl->datas[i], 0, sizeof(MotorData_t));
        ctrl->datas[i].motor_id = i;

    }


}



/**
  * @brief 设置电机控制参数
  */
void MotorController_SetCommand(MotorController* ctrl,
                              uint8_t motor_id,
                              uint8_t mode,
                              float torque,
                              float speed,
                              float position,
                              float k_p,
                              float k_w) {
    if ( motor_id > MOTOR_NUM) return;

    uint8_t idx = motor_id;
    ctrl->cmds[idx].mode = mode;
    ctrl->cmds[idx].T = torque;
    ctrl->cmds[idx].W = speed;
    ctrl->cmds[idx].Pos = position;
    ctrl->cmds[idx].K_P = k_p;
    ctrl->cmds[idx].K_W = k_w;

    modify_data(&ctrl->cmds[idx]);     // 更新协议数据
}

/**
  * @brief 发送单个电机指令
  * @return 0成功, -1失败
  */
int MotorController_SendCommand1(MotorController* ctrl, uint8_t motor_id) {
    if (motor_id >= MOTOR_NUM || ctrl->dma_busy) {
        return -1; // 电机ID无效或DMA正忙
    }

    ctrl->last_sent_motor_id = motor_id;
    // 设置发送模式
    RS485_TxMode1();

    // 标记DMA忙碌状态
    ctrl->dma_busy = 1;

    // 启动DMA发送
    HAL_StatusTypeDef status = HAL_UART_Transmit_DMA(
        ctrl->uart,
        (uint8_t*)&ctrl->cmds[motor_id].motor_send_data,
        sizeof(ctrl->cmds[motor_id].motor_send_data));

    return (status == HAL_OK) ? 0 : -1;
}



/**
  * @brief 发送单个电机指令
  * @return 0成功, -1失败
  */
int MotorController_SendCommand2(MotorController* ctrl, uint8_t motor_id) {
//    if (motor_id >= MOTOR_NUM || ctrl->dma_busy) {
//        return -1; // 电机ID无效或DMA正忙
//    }

    ctrl->last_sent_motor_id = motor_id;
    // 设置发送模式
    RS485_TxMode2();

    // 标记DMA忙碌状态
    ctrl->dma_busy = 1;

    // 启动DMA发送
    HAL_StatusTypeDef status = HAL_UART_Transmit_DMA(
        ctrl->uart,
        (uint8_t*)&ctrl->cmds[motor_id].motor_send_data,
        sizeof(ctrl->cmds[motor_id].motor_send_data));

    return (status == HAL_OK) ? 0 : -1;
}

void MotorController_ReceiveData1(MotorController* ctrl) {
    RS485_RxMode1();

    for (uint8_t i = 0; i < MOTOR_NUM; i++) {
        HAL_StatusTypeDef rx_res = HAL_UART_Receive(
            ctrl->uart,
            (uint8_t*)&ctrl->datas[i].motor_recv_data,
            sizeof(ctrl->datas[i].motor_recv_data),
            1);

        if (rx_res == HAL_TIMEOUT) {
            ctrl->datas[i].timeout++;
            continue;
        }

        extract_data(&ctrl->datas[i]);

        if (ctrl->datas[i].MError != 0) {
            // 电机错误处理
            // 例如: 控制其他电机进入阻尼状态
        }
    }
}


void MotorController_ReceiveData2(MotorController* ctrl) {
    RS485_RxMode2();

    for (uint8_t i = 0; i < MOTOR_NUM; i++) {
        HAL_StatusTypeDef rx_res = HAL_UART_Receive(
            ctrl->uart,
            (uint8_t*)&ctrl->datas[i].motor_recv_data,
            sizeof(ctrl->datas[i].motor_recv_data),
            1);

        if (rx_res == HAL_TIMEOUT) {
            ctrl->datas[i].timeout++;
            continue;
        }

        extract_data(&ctrl->datas[i]);

        if (ctrl->datas[i].MError != 0) {
            // 电机错误处理
            // 例如: 控制其他电机进入阻尼状态
        }
    }
}


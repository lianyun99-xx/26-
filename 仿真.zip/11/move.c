#include <math.h>
#define PI 3.14159265358979323846f

float sqrt_float(float x) {
    return sqrtf(x);
}

double sqrt_double(double x) {
    return sqrt(x);
}

uint8_t ForwardKinematics(Motor_Data*motor_r, Motor_Data*motor_s) {
    float motor8010_data_lastpos = 0;
    float pos = motor_s->pos;
    float L1 = 185.0f;
    float L2 = 215.0f;
    float L3 = 0.0f;
    float theta1 = 0.0f;
    float theta2 = 0.0f;
    float theta3 = 0.0f;
    float theta4 = 0.0f;
    float Y = 0.0f;
    float Z = 0.0f;
    
    theta1 = (motor_r->lastpos - motor_r->pos);
    theta2 = motor_s->pos - motor_s->lastpos;
    L3 = sqrtf(L1*L1 + L2*L2 + 2.0f*L1*L2*cosf(theta2));
    theta3 = asinf(L2*sinf(theta2)/L3);
    theta4 = theta1 + theta3;
    Y = L3*cosf(theta4);
    Z = L3*sinf(theta4);
    
    motor_r->lastpos = motor_r->pos;
    motor_s->lastpos = motor_s->pos;
    
    return 0;
}

uint8_t InverseKinematics(float Y, float Z) {
    float L1 = 185.0f;
    float L2 = 215.0f;
    float L3 = 0.0f;
    float theta1 = 0.0f;
    float theta2 = 0.0f;
    float theta3 = 0.0f;
    float theta4 = 0.0f;
    float theta5 = 0.0f;
    
    L3 = sqrtf(Y*Y + Z*Z);
    
    if(Y > 0 && Z > 0) {
        theta4 = atan2f(Z, Y);
        float cos_theta2 = (L1*L1 + L2*L2 - L3*L3) / (2.0f*L1*L2);
        cos_theta2 = fmaxf(-1.0f, fminf(1.0f, cos_theta2));
        theta2 = acosf(cos_theta2);
        theta3 = asinf(L2*sinf(theta2)/L3);
        theta1 = theta4 - theta3;
    }
    else if(Y < 0 && Z > 0) {
        theta5 = atan2f(Z, Y);
        theta1 = PI/2.0f - theta5;
        float cos_theta2 = (L1*L1 + L2*L2 - L3*L3) / (2.0f*L1*L2);
        cos_theta2 = fmaxf(-1.0f, fminf(1.0f, cos_theta2));
        theta2 = acosf(cos_theta2);
    }
    else {
        return 1;
    }
    
    return 0;
}

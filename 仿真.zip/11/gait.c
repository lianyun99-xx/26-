

#define PI 3.14159265358979323846  // 圆周率
starttime=hal_gettick
float t;//瞬时运动时间
float cycle_time;//运动周期总时间
float error_time;//经过的时间
float dt;//归一化时间
error_time=t-starttime;
dt=error_time/cycle_time
typedef struct {
    float x;  // X 轴当前位移坐标
    float y;  // Y 轴当前位移坐标
} Cycloid2D_Pose
Cycloid2D_Pose cycloid_2d_displacement(float t,
                                       float starttime,
                                       float cycle_time,
                                       float x_start,
                                       float x_target,
                                       float y_start,
                                       float y_target)
{
    Cycloid2D_Pose current_pose;
    float error_time = t - starttime;
    if (error_time < 0.0f)
    {
        current_pose.x = x_start;
        current_pose.y = y_start;
        return current_pose;
    }
    else if (error_time >= cycle_time)
    {
        current_pose.x = x_target;
        current_pose.y = y_target;
        return current_pose;
    }
    float dt = error_time / cycle_time;
    float delta_x = x_target - x_start;
    float move_x = dt - (1.0f / (2.0f * PI)) * sin(2.0f * PI * dt);
    current_pose.x = x_start + delta_x * move_x;
    float delta_y = y_target - y_start;
    float move_y = dt - (1.0f / (2.0f * PI)) * sin(2.0f * PI * dt);
    current_pose.y = y_start + delta_y * move_y;
    return current_pose;
}
Cycloid2D_Pose cycloid_2d_displacement(float t,
                                       float starttime,
                                       float cycle_time,
                                       float x_start,
                                       float x_target,
                                       float y_start,
                                       float y_target)
{
    Cycloid2D_Pose current_pose;
    float error_time = t - starttime;
    if (error_time < 0.0f)
    {
        current_pose.x = x_start;
        current_pose.y = y_start;
        return current_pose;
    }
    else if (error_time >= cycle_time)
    {
        current_pose.x = x_target;
        current_pose.y = y_target;
        return current_pose;
    }
    float dt = error_time / cycle_time;
    float delta_x = x_target - x_start;
    float move_x = dt - (1.0f / (2.0f * PI)) * sin(2.0f * PI * dt);
    current_pose.x = x_start + delta_x * move_x;
    float delta_y = y_target - y_start;
    float move_y = dt - (1.0f / (2.0f * PI)) * sin(2.0f * PI * dt);
    current_pose.y = y_start + delta_y * move_y;
    return current_pose;
}





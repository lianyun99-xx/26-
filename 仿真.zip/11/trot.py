import sys
import numpy as np
import matplotlib

# ==========================================
# 关键修复 1: 强制使用兼容性最好的 TkAgg 后端
# ==========================================
try:
    matplotlib.use('TkAgg')
except:
    pass # 如果失败，尝试使用默认后端

import matplotlib.pyplot as plt
import mpl_toolkits.mplot3d.axes3d as p3
from matplotlib.animation import FuncAnimation

# ==========================================
# 1. 数学模型 (保持不变)
# ==========================================
PI = np.pi

def cycloid_2d_arch_trajectory(t, starttime, cycle_time, x_start, x_target, y_start, y_target, lift_height):
    error_time = t - starttime
    if error_time < 0: error_time = 0
    if error_time > cycle_time: error_time = cycle_time
    dt = error_time / cycle_time
    delta_x = x_target - x_start
    delta_y = y_target - y_start
    x = x_start + delta_x * (dt - np.sin(2 * PI * dt) / (2 * PI))
    z = y_start + delta_y * dt + lift_height * (1 - np.cos(2 * PI * dt)) / 2.0 
    return x, z

def straight_line_trajectory(t, starttime, cycle_time, x_start, x_target, y_start, y_target):
    error_time = t - starttime
    if error_time < 0: error_time = 0
    if error_time > cycle_time: error_time = cycle_time
    dt = error_time / cycle_time
    x = x_start + (x_target - x_start) * dt
    z = y_start + (y_target - y_start) * dt
    return x, z

def solve_leg_ik_2d(hip_pos, foot_pos, L1, L2, bend_direction=-1):
    hx, hz = hip_pos
    fx, fz = foot_pos
    dx = fx - hx
    dz = fz - hz
    D_sq = dx**2 + dz**2
    D = np.sqrt(D_sq)
    if D > (L1 + L2) or D < abs(L1 - L2) or D == 0:
        return None 
    cos_alpha = (L1**2 + D_sq - L2**2) / (2 * L1 * D)
    cos_alpha = np.clip(cos_alpha, -1.0, 1.0)
    alpha = np.arccos(cos_alpha)
    theta = np.arctan2(dz, dx)
    knee_angle = theta + bend_direction * alpha
    kx = hx + L1 * np.cos(knee_angle)
    kz = hz + L1 * np.sin(knee_angle)
    return (kx, kz)

# ==========================================
# 2. 机器人配置
# ==========================================
class Robot3DConfig:
    def __init__(self):
        self.body_dim = (0.40, 0.20)
        self.thigh_len = 0.20
        self.shank_len = 0.20
        self.stand_height = 0.30 
        self.cycle_time = 0.8     
        self.stride_length = 0.20  
        self.lift_height = 0.10    
        self.fps = 30
        self.duration = 4.0

# ==========================================
# 3. 3D 可视化器
# ==========================================
class Quadruped3DVisualizer:
    def __init__(self, config):
        self.cfg = config
        self.fig = plt.figure(figsize=(10, 8))
        self.ax = self.fig.add_subplot(111, projection='3d') # 标准 3D 初始化
        
        self.ax.set_title("3D Quadruped Trot Animation", fontsize=12)
        self.ax.set_xlabel("X (Forward)")
        self.ax.set_ylabel("Y (Side)")
        self.ax.set_zlabel("Z (Height)")
        
        limit = 0.5
        self.ax.set_xlim(-0.5, 1.0)
        self.ax.set_ylim(-limit, limit)
        self.ax.set_zlim(0, 0.6)
        
        # 初始化绘图对象
        self.init_robot_plots()
        self.time_data = np.linspace(0, self.cfg.duration, int(self.cfg.duration * self.cfg.fps))
        
        # 关键修复 2: 声明 self.ani 防止被垃圾回收
        self.ani = None 

    def init_robot_plots(self):
        # 绘制机身
        self.body_lines = [self.ax.plot([], [], [], 'k-', linewidth=3, alpha=0.8)[0] for _ in range(4)]
        
        self.legs_visuals = []
        for i in range(4):
            parts = {
                'thigh': self.ax.plot([], [], [], '-', linewidth=4)[0],
                'shank': self.ax.plot([], [], [], '-', linewidth=4)[0],
                'joints': self.ax.plot([], [], [], 'o', markersize=5, markeredgecolor='k')[0]
            }
            self.legs_visuals.append(parts)
            
        bx, by = self.cfg.body_dim
        self.hip_offsets = [
            (bx/2, by/2), (bx/2, -by/2), (-bx/2, by/2), (-bx/2, -by/2)
        ]
        self.knee_bend_dirs = [-1, -1, 1, 1]

    def update_scene(self, frame):
        current_t = self.time_data[frame]
        cycle_time = self.cfg.cycle_time
        half_cycle = cycle_time / 2.0
        
        cycle_count = int(current_t / cycle_time)
        time_in_cycle = current_t - cycle_count * cycle_time
        
        # 简单的机身移动
        body_x_pos = current_t * 0.25 
        world_body_pos = np.array([body_x_pos, 0, self.cfg.stand_height])
        
        # 更新机身绘图
        bx, by = self.cfg.body_dim
        # 定义机身的四个角 (局部)
        corners_local = [
            [bx/2, by/2, 0], [bx/2, -by/2, 0],   # 前面那条边
            [bx/2, -by/2, 0], [-bx/2, -by/2, 0], # 右边那条边
            [-bx/2, -by/2, 0], [-bx/2, by/2, 0], # 后面那条边
            [-bx/2, by/2, 0], [bx/2, by/2, 0]    # 左边那条边
        ]
        
        # 绘制机身的四条边
        for j in range(4):
            idx1 = j * 2
            idx2 = j * 2 + 1
            c1 = np.array(corners_local[idx1]) + world_body_pos
            c2 = np.array(corners_local[idx2]) + world_body_pos
            self.body_lines[j].set_data([c1[0], c2[0]], [c1[1], c2[1]])
            self.body_lines[j].set_3d_properties([c1[2], c2[2]])

        # 更新四条腿
        for i in range(4):
            is_group_A = (i == 0 or i == 3)
            is_swing = False
            target_foot_xz = (0, 0)

            # 步态逻辑
            if is_group_A:
                if time_in_cycle < half_cycle: # Swing
                    is_swing = True
                    start = cycle_count * cycle_time
                    target_foot_xz = cycloid_2d_arch_trajectory(
                        current_t, start, half_cycle, 
                        -self.cfg.stride_length/2, self.cfg.stride_length/2, 
                        -self.cfg.stand_height, -self.cfg.stand_height, self.cfg.lift_height)
                else: # Stance
                    start = cycle_count * cycle_time + half_cycle
                    target_foot_xz = straight_line_trajectory(
                        current_t, start, half_cycle,
                        self.cfg.stride_length/2, -self.cfg.stride_length/2,
                        -self.cfg.stand_height, -self.cfg.stand_height)
            else:
                if time_in_cycle < half_cycle: # Stance
                    start = cycle_count * cycle_time
                    target_foot_xz = straight_line_trajectory(
                        current_t, start, half_cycle,
                        self.cfg.stride_length/2, -self.cfg.stride_length/2,
                        -self.cfg.stand_height, -self.cfg.stand_height)
                else: # Swing
                    is_swing = True
                    start = cycle_count * cycle_time + half_cycle
                    target_foot_xz = cycloid_2d_arch_trajectory(
                        current_t, start, half_cycle,
                        -self.cfg.stride_length/2, self.cfg.stride_length/2,
                        -self.cfg.stand_height, -self.cfg.stand_height, self.cfg.lift_height)
            
            # IK 计算
            knee_xz = solve_leg_ik_2d((0,0), target_foot_xz, self.cfg.thigh_len, self.cfg.shank_len, self.knee_bend_dirs[i])
            if knee_xz is None: knee_xz = (0, -0.2) # 默认防错

            # 坐标转换 (局部->世界)
            hip_world = world_body_pos + np.array([self.hip_offsets[i][0], self.hip_offsets[i][1], 0])
            p_knee = hip_world + np.array([knee_xz[0], 0, knee_xz[1]])
            p_foot = hip_world + np.array([target_foot_xz[0], 0, target_foot_xz[1]])
            
            # 颜色设置
            color = 'red' if is_swing else 'blue'
            alpha = 0.9 if is_swing else 0.5

            # 绘制大腿
            self.legs_visuals[i]['thigh'].set_data([hip_world[0], p_knee[0]], [hip_world[1], p_knee[1]])
            self.legs_visuals[i]['thigh'].set_3d_properties([hip_world[2], p_knee[2]])
            self.legs_visuals[i]['thigh'].set_color(color)
            self.legs_visuals[i]['thigh'].set_alpha(alpha)

            # 绘制小腿
            self.legs_visuals[i]['shank'].set_data([p_knee[0], p_foot[0]], [p_knee[1], p_foot[1]])
            self.legs_visuals[i]['shank'].set_3d_properties([p_knee[2], p_foot[2]])
            self.legs_visuals[i]['shank'].set_color(color)
            self.legs_visuals[i]['shank'].set_alpha(alpha)
            
            # 绘制关节
            jx = [hip_world[0], p_knee[0], p_foot[0]]
            jy = [hip_world[1], p_knee[1], p_foot[1]]
            jz = [hip_world[2], p_knee[2], p_foot[2]]
            self.legs_visuals[i]['joints'].set_data(jx, jy)
            self.legs_visuals[i]['joints'].set_3d_properties(jz)
            self.legs_visuals[i]['joints'].set_color(color)

    def run(self):
        # 关键修复 2：将 ani 赋值给 self.ani，防止被垃圾回收
        self.ani = FuncAnimation(
            self.fig, 
            self.update_scene, 
            frames=len(self.time_data), 
            interval=30, # 约30fps
            blit=False   # 3D 绘图通常不支持 blit
        )
        plt.show()

if __name__ == "__main__":
    config = Robot3DConfig()
    vis = Quadruped3DVisualizer(config)
    vis.run()
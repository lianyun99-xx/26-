import math
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.widgets import Slider, Button

PI = 3.14159265358979323846

L1 = 185
L2 = 215

def sqrt_float(x):
    return math.sqrt(x)

def sqrt_double(x):
    return math.sqrt(x)

def forward_kinematics(motor_r, motor_s):
    motor8010_data_lastpos = 0
    pos = motor_s['pos']
    L3 = 0
    theta1 = 0
    theta2 = 0
    theta3 = 0
    theta4 = 0
    Y = 0
    Z = 0
    
    theta1 = motor_r['lastpos'] - motor_r['pos']
    theta2 = motor_s['pos'] - motor_s['lastpos']
    L3 = math.sqrt(L1 * L1 + L2 * L2 + 2 * L1 * L2 * math.cos(theta2))
    theta3 = math.asin(L2 * math.sin(theta2) / L3)
    theta4 = theta1 + theta3
    Y = L3 * math.cos(theta4)
    Z = L3 * math.sin(theta4)
    
    motor_r['lastpos'] = motor_r['pos']
    motor_s['lastpos'] = motor_s['pos']
    
    hip_angle = theta1
    knee_angle = theta2
    
    x1 = 0
    y1 = 0
    x2 = L1 * math.cos(hip_angle)
    y2 = L1 * math.sin(hip_angle)
    x3 = x2 + L2 * math.cos(hip_angle + knee_angle)
    y3 = y2 + L2 * math.sin(hip_angle + knee_angle)
    
    return {
        'theta1': theta1,
        'theta2': theta2,
        'theta3': theta3,
        'theta4': theta4,
        'hip_angle': hip_angle,
        'knee_angle': knee_angle,
        'L1': L1,
        'L2': L2,
        'L3': L3,
        'Y': Y,
        'Z': Z,
        'joint1': (x1, y1),
        'joint2': (x2, y2),
        'joint3': (x3, y3)
    }

def inverse_kinematics(Y, Z):
    L3 = math.sqrt(Y * Y + Z * Z)
    
    if L3 > L1 + L2:
        L3 = L1 + L2
        scale = L3 / math.sqrt(Y * Y + Z * Z)
        Y = Y * scale
        Z = Z * scale
    
    if Y > 0 and Z > 0:
        theta4 = math.atan2(Z, Y)
        cos_theta2 = (L1 * L1 + L2 * L2 - L3 * L3) / (2 * L1 * L2)
        cos_theta2 = max(-1, min(1, cos_theta2))
        theta2 = math.acos(cos_theta2)
        theta3 = math.asin(L2 * math.sin(theta2) / L3)
        theta1 = theta4 - theta3
    elif Y < 0 and Z < 0:
        theta5 = math.atan2(Z, Y)
        theta1 = PI / 2 - theta5
        cos_theta2 = (L1 * L1 + L2 * L2 - L3 * L3) / (2 * L1 * L2)
        cos_theta2 = max(-1, min(1, cos_theta2))
        theta2 = math.acos(cos_theta2)
    else:
        theta4 = math.atan2(Z, Y)
        cos_theta2 = (L1 * L1 + L2 * L2 - L3 * L3) / (2 * L1 * L2)
        cos_theta2 = max(-1, min(1, cos_theta2))
        theta2 = math.acos(cos_theta2)
        theta3 = math.asin(L2 * math.sin(theta2) / L3)
        theta1 = theta4 - theta3
    
    return {
        'theta1': theta1,
        'theta2': theta2,
        'theta3': theta3,
        'theta4': theta4,
        'L1': L1,
        'L2': L2,
        'L3': L3,
        'Y': Y,
        'Z': Z
    }

class KinematicsVisualizer:
    def __init__(self):
        self.fig, self.ax = plt.subplots(figsize=(14, 10))
        plt.subplots_adjust(left=0.1, bottom=0.25)
        
        self.motor_r_pos_init = 0.0
        self.motor_r_lastpos_init = 0.0
        self.motor_s_pos_init = 0.5
        self.motor_s_lastpos_init = 0.0
        
        self.setup_plot()
        self.setup_sliders()
        self.setup_mouse_interaction()
        self.update_robot(self.motor_r_pos_init, self.motor_r_lastpos_init, 
                       self.motor_s_pos_init, self.motor_s_lastpos_init)
        
    def setup_plot(self):
        self.ax.set_xlim(-500, 500)
        self.ax.set_ylim(-50, 500)
        self.ax.set_aspect('equal')
        self.ax.grid(True, alpha=0.3)
        self.ax.set_xlabel('Y Position (mm)')
        self.ax.set_ylabel('Z Position (mm)')
        self.ax.set_title('Wheel-Leg Robot Kinematics Visualization')
        
        self.thigh_line, = self.ax.plot([], [], 'o-', linewidth=4, markersize=12, color='red', label='Thigh (L1)')
        self.shank_line, = self.ax.plot([], [], 'o-', linewidth=4, markersize=12, color='green', label='Shank (L2)')
        self.end_point, = self.ax.plot([], [], 'ro', markersize=15, label='End Effector')
        self.target_point, = self.ax.plot([], [], 'bx', markersize=12, label='Target (Click)')
        self.ax.legend()
        
        self.info_text = self.ax.text(0.02, 0.98, '', transform=self.ax.transAxes, 
                                      verticalalignment='top', fontsize=10,
                                      bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))
        
    def setup_sliders(self):
        ax_motor_r_pos = plt.axes([0.15, 0.18, 0.7, 0.03])
        ax_motor_r_lastpos = plt.axes([0.15, 0.14, 0.7, 0.03])
        ax_motor_s_pos = plt.axes([0.15, 0.10, 0.7, 0.03])
        ax_motor_s_lastpos = plt.axes([0.15, 0.06, 0.7, 0.03])
        
        self.slider_motor_r_pos = Slider(ax_motor_r_pos, 'Motor_R Pos (rad)', -PI, PI, valinit=self.motor_r_pos_init)
        self.slider_motor_r_lastpos = Slider(ax_motor_r_lastpos, 'Motor_R LastPos (rad)', -PI, PI, valinit=self.motor_r_lastpos_init)
        self.slider_motor_s_pos = Slider(ax_motor_s_pos, 'Motor_S Pos (rad)', -PI, PI, valinit=self.motor_s_pos_init)
        self.slider_motor_s_lastpos = Slider(ax_motor_s_lastpos, 'Motor_S LastPos (rad)', -PI, PI, valinit=self.motor_s_lastpos_init)
        
        self.slider_motor_r_pos.on_changed(self.on_slider_change)
        self.slider_motor_r_lastpos.on_changed(self.on_slider_change)
        self.slider_motor_s_pos.on_changed(self.on_slider_change)
        self.slider_motor_s_lastpos.on_changed(self.on_slider_change)
        
        ax_reset = plt.axes([0.8, 0.01, 0.1, 0.03])
        self.btn_reset = Button(ax_reset, 'Reset')
        self.btn_reset.on_clicked(self.reset)
        
    def setup_mouse_interaction(self):
        self.fig.canvas.mpl_connect('button_press_event', self.on_click)
        
    def on_click(self, event):
        if event.inaxes != self.ax:
            return
        
        target_y = event.xdata
        target_z = event.ydata
        
        inv_result = inverse_kinematics(target_y, target_z)
        
        self.slider_motor_r_pos.set_val(inv_result['theta1'])
        self.slider_motor_r_lastpos.set_val(0.0)
        self.slider_motor_s_pos.set_val(inv_result['theta2'])
        self.slider_motor_s_lastpos.set_val(0.0)
        
        self.target_point.set_data([target_y], [target_z])
        self.fig.canvas.draw_idle()
        
    def on_slider_change(self, val):
        motor_r_pos = self.slider_motor_r_pos.val
        motor_r_lastpos = self.slider_motor_r_lastpos.val
        motor_s_pos = self.slider_motor_s_pos.val
        motor_s_lastpos = self.slider_motor_s_lastpos.val
        self.update_robot(motor_r_pos, motor_r_lastpos, motor_s_pos, motor_s_lastpos)
        
    def update_robot(self, motor_r_pos, motor_r_lastpos, motor_s_pos, motor_s_lastpos):
        motor_r = {
            'pos': motor_r_pos,
            'lastpos': motor_r_lastpos
        }
        motor_s = {
            'pos': motor_s_pos,
            'lastpos': motor_s_lastpos
        }
        
        result = forward_kinematics(motor_r, motor_s)
        
        x1, y1 = result['joint1']
        x2, y2 = result['joint2']
        x3, y3 = result['joint3']
        
        self.thigh_line.set_data([x1, x2], [y1, y2])
        self.shank_line.set_data([x2, x3], [y2, y3])
        self.end_point.set_data([x3], [y3])
        
        info = f'Forward Kinematics:\n'
        info += f'Motor_R:\n'
        info += f'  pos: {motor_r_pos:.4f} rad ({math.degrees(motor_r_pos):.2f}°)\n'
        info += f'  lastpos: {motor_r_lastpos:.4f} rad ({math.degrees(motor_r_lastpos):.2f}°)\n'
        info += f'Motor_S:\n'
        info += f'  pos: {motor_s_pos:.4f} rad ({math.degrees(motor_s_pos):.2f}°)\n'
        info += f'  lastpos: {motor_s_lastpos:.4f} rad ({math.degrees(motor_s_lastpos):.2f}°)\n\n'
        info += f'Calculated Angles (rad):\n'
        info += f'  theta1: {result["theta1"]:.4f}\n'
        info += f'  theta2: {result["theta2"]:.4f}\n'
        info += f'  theta3: {result["theta3"]:.4f}\n'
        info += f'  theta4: {result["theta4"]:.4f}\n\n'
        info += f'Leg Angles (rad):\n'
        info += f'  Hip Angle (theta1): {result["hip_angle"]:.4f}\n'
        info += f'  Knee Angle (theta2): {result["knee_angle"]:.4f}\n\n'
        info += f'Link Lengths:\n'
        info += f'  L1 (Thigh): {result["L1"]:.2f} mm\n'
        info += f'  L2 (Shank): {result["L2"]:.2f} mm\n'
        info += f'  L3: {result["L3"]:.2f} mm\n\n'
        info += f'End Effector Position:\n'
        info += f'  Y: {x3:.2f} mm\n'
        info += f'  Z: {y3:.2f} mm\n'
        
        inv_result = inverse_kinematics(x3, y3)
        info += f'\nInverse Kinematics Check:\n'
        info += f'  theta1: {inv_result["theta1"]:.4f}\n'
        info += f'  theta2: {inv_result["theta2"]:.4f}\n'
        info += f'  theta3: {inv_result["theta3"]:.4f}\n'
        info += f'  theta4: {inv_result["theta4"]:.4f}\n'
        
        self.info_text.set_text(info)
        
        self.fig.canvas.draw_idle()
        
    def reset(self, event):
        self.slider_motor_r_pos.reset()
        self.slider_motor_r_lastpos.reset()
        self.slider_motor_s_pos.reset()
        self.slider_motor_s_lastpos.reset()
        self.target_point.set_data([], [])
        
    def show(self):
        plt.show()

if __name__ == '__main__':
    print("Wheel-Leg Robot Kinematics Visualization")
    print("=========================================")
    print("Showing both thigh and shank angles")
    print("\nControls:")
    print("- Motor_R Pos/LastPos: Control motor R (hip - theta1)")
    print("- Motor_S Pos/LastPos: Control motor S (knee - theta2)")
    print("- Click on plot: Move leg to target position (inverse kinematics)")
    print("- Click 'Reset': Return to initial position")
    print("\nAll angles are in radians")
    print("theta1 controls thigh (hip), theta2 controls shank (knee)")
    
    visualizer = KinematicsVisualizer()
    visualizer.show()

import math
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
import numpy as np

PI = math.pi

class Pose2D:
    """2D位置类，存储x和y坐标"""
    def __init__(self, x=0.0, y=0.0):
        self.x = x
        self.y = y

def cycloid_trajectory(t, start_time, cycle_time, x_start, x_target, y_start, y_target, lift_height=50.0):
    """
    生成真正的拱形摆线轨迹（空间轨迹呈拱形）
    
    参数:
        t: 当前时间
        start_time: 运动开始时间
        cycle_time: 运动周期
        x_start/y_start: 起始位置
        x_target/y_target: 目标位置
        lift_height: 抬升高度（拱形最高点）
    
    返回: 当前位置 (Pose2D对象)
    """
    current_pose = Pose2D()
    elapsed = t - start_time
    
    # 未开始运动
    if elapsed < 0.0:
        current_pose.x = x_start
        current_pose.y = y_start
        return current_pose
    # 已完成运动
    elif elapsed >= cycle_time:
        current_pose.x = x_target
        current_pose.y = y_target
        return current_pose
    
    # 归一化时间参数 [0, 1]
    s = elapsed / cycle_time
    
    # 摆线运动公式（拱形轨迹的关键）:
    # x方向: 线性位移 + 摆线分量
    # y方向: 基础位移 + 拱形抬升分量
    x_displacement = x_target - x_start
    y_displacement = y_target - y_start
    
    # 拱形轨迹的核心计算
    # 注意: 摆线公式中 y = r(1 - cosθ) 实现抬升效果
    current_pose.x = x_start + x_displacement * (s - math.sin(2 * PI * s) / (2 * PI))
    current_pose.y = y_start + y_displacement * s + lift_height * (1 - math.cos(2 * PI * s)) / 2
    
    return current_pose

def straight_line_trajectory(t, start_time, cycle_time, x_start, x_target, y_start, y_target):
    """
    生成直线返回轨迹
    
    参数: 同摆线轨迹
    返回: 当前位置 (Pose2D对象)
    """
    current_pose = Pose2D()
    elapsed = t - start_time
    
    # 未开始运动
    if elapsed < 0.0:
        current_pose.x = x_start
        current_pose.y = y_start
        return current_pose
    # 已完成运动
    elif elapsed >= cycle_time:
        current_pose.x = x_target
        current_pose.y = y_target
        return current_pose
    
    # 直线运动 (匀速)
    s = elapsed / cycle_time
    current_pose.x = x_start + (x_target - x_start) * s
    current_pose.y = y_start + (y_target - y_start) * s
    
    return current_pose

def visualize_cycloid_gait():
    """可视化摆线去程(拱形) + 直线返程的动画"""
    # 运动参数设置
    x_start, y_start = 0.0, 0.0      # 起始位置
    x_target, y_target = 300.0, 0.0   # 目标位置 (y_target=0 保持地面高度)
    cycle_time = 2.0                 # 单程运动时间(秒)
    total_time = cycle_time * 2      # 总动画时间(秒)
    lift_height = 80.0               # 拱形抬升高度
    
    # 生成轨迹数据
    time_steps = 300                 # 提高采样率使拱形更平滑
    total_steps = time_steps * 2     # 总采样点数
    trajectory = []                  # 存储轨迹点
    time_points = []                 # 存储时间点
    
    # 计算完整轨迹 (去程摆线 + 返程直线)
    for i in range(total_steps):
        t = (i / (total_steps - 1)) * total_time
        if t <= cycle_time:
            # 去程: 拱形摆线运动 (0s ~ 2s)
            pose = cycloid_trajectory(
                t, 0.0, cycle_time, 
                x_start, x_target, 
                y_start, y_target,
                lift_height
            )
        else:
            # 返程: 直线运动 (2s ~ 4s)
            pose = straight_line_trajectory(
                t, cycle_time, cycle_time, 
                x_target, x_start, 
                y_target, y_start
            )
        trajectory.append((pose.x, pose.y))
        time_points.append(t)
    
    # 提取坐标
    traj_x, traj_y = zip(*trajectory)
    
    # 创建可视化
    fig = plt.figure(figsize=(14, 8))
    ax = fig.add_subplot(111)
    ax.set_xlim(-50, 350)
    ax.set_ylim(-20, 120)  # 调整y轴范围以显示拱形
    ax.set_aspect('equal', 'box')
    ax.grid(True, linestyle='--', alpha=0.7)
    ax.set_title('Cycloid Gait: Arch Trajectory to Target + Straight Return', fontsize=16, pad=20)
    ax.set_xlabel('X Position (mm)', fontsize=12, labelpad=10)
    ax.set_ylabel('Y Position (mm)', fontsize=12, labelpad=10)
    
    # 绘制参考元素
    ax.plot(x_start, y_start, 'gs', markersize=15, label='Start Position (0, 0)')
    ax.plot(x_target, y_target, 'ms', markersize=15, label='Target Position (300, 0)')
    
    # 绘制地面线
    ground_x = np.linspace(-50, 350, 100)
    ground_y = np.zeros_like(ground_x)
    ax.plot(ground_x, ground_y, 'k-', linewidth=2, alpha=0.3, label='Ground Level')
    
    # 绘制直线参考线
    ax.plot([x_start, x_target], [y_start, y_target], 'k--', alpha=0.5, label='Direct Path')
    
    # 动画元素
    trajectory_line, = ax.plot([], [], 'b-', linewidth=3, alpha=0.9, label='Cycloid Trajectory')
    current_point, = ax.plot([], [], 'ro', markersize=12, label='Current Position')
    
    # 添加拱形说明
    ax.text(0.02, 0.02, 
            'Phase 1 (0-2s): Arch-shaped cycloid motion\n  - Smooth acceleration/deceleration\n  - Foot lift for obstacle clearance\nPhase 2 (2-4s): Straight line return', 
            transform=ax.transAxes, fontsize=10, 
            bbox=dict(facecolor='white', alpha=0.8, edgecolor='gray'))
    
    # 动画更新函数
    def update(frame):
        # 更新轨迹
        if frame > 0:
            cx, cy = zip(*trajectory[:frame+1])
            trajectory_line.set_data(cx, cy)
        
        # 更新当前位置
        current_x, current_y = trajectory[frame]
        current_point.set_data([current_x], [current_y])
        
        return trajectory_line, current_point
    
    # 创建动画 (33ms间隔 ≈ 30fps)
    ani = FuncAnimation(
        fig, 
        update, 
        frames=total_steps, 
        interval=33, 
        blit=True,
        repeat=False
    )
    
    # 添加图例
    ax.legend(loc='upper right', fontsize=10)
    
    plt.tight_layout()
    plt.show()

if __name__ == '__main__':
    print("="*60)
    print("摆线步态: 拱形轨迹前往目标位置 + 直线返回 动画演示")
    print("="*60)
    print(f"起始位置: (0.0, 0.0) - 地面高度")
    print(f"目标位置: (300.0, 0.0) - 地面高度")
    print(f"拱形抬升高度: 80.0 mm")
    print(f"单程时间: 2.0 秒")
    print(f"总动画时长: 4.0 秒")
    print("\n运动阶段说明:")
    print("1. [0-2秒] 拱形摆线运动:")
    print("   - X方向: 摆线速度曲线 (平滑加速/减速)")
    print("   - Y方向: 拱形抬升 (最高点80mm, 避开障碍物)")
    print("2. [2-4秒] 直线返回:")
    print("   - 沿地面直线匀速返回起点")
    print("\n可视化元素:")
    print("- 蓝色实线: 运动轨迹 (去程拱形, 返程直线)")
    print("- 红色圆点: 当前位置")
    print("- 绿色方块: 起始位置")
    print("- 紫色方块: 目标位置")
    print("- 黑色实线: 地面参考")
    print("- 黑色虚线: 起点到终点的直线参考")
    print("="*60)
    
    visualize_cycloid_gait()

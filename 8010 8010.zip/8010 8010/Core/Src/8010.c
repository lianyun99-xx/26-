/*
 * 8010.c
 *
 *  Created on: Jan 3, 2026
 *      Author: nianyun
 */

#include "8010.h"
#include <string.h>
#include "stm32f4xx_hal.h"

// 定义全局电机控制器实例
MotorController ctrl;

#define SATURATE(_IN, _MIN, _MAX) \
	{                             \
		if ((_IN) <= (_MIN))      \
			(_IN) = (_MIN);       \
		else if ((_IN) >= (_MAX)) \
			(_IN) = (_MAX);       \
	}


void modify_data(MotorCmd_t *motor_s)
{
	motor_s->motor_send_data.head[0] = 0xFE;
	motor_s->motor_send_data.head[1] = 0xEE;

	SATURATE(motor_s->id, 0, 15);
	SATURATE(motor_s->mode, 0, 7);
	SATURATE(motor_s->K_P, 0.0f, 25.599f);
	SATURATE(motor_s->K_W, 0.0f, 25.599f);
	SATURATE(motor_s->T, -127.99f, 127.99f);
	SATURATE(motor_s->W, -804.00f, 804.00f);
	SATURATE(motor_s->Pos, -411774.0f, 411774.0f);

	    motor_s->motor_send_data.mode.id = motor_s->id;
    motor_s->motor_send_data.mode.status = motor_s->mode;

    // 明确的类型转换和注释说明转换系数
    // K_P: 0.0-25.599 → q15 (0-32767)
    motor_s->motor_send_data.comd.k_pos = (int16_t)(motor_s->K_P * 1279.2f);  // 32768/25.6
    // K_W: 0.0-25.599 → q15 (0-32767)
    motor_s->motor_send_data.comd.k_spd = (int16_t)(motor_s->K_W * 1279.2f);  // 32768/25.6
    // Pos: rad → q15 (0-32767代表0-2π)
    motor_s->motor_send_data.comd.pos_des = (int32_t)(motor_s->Pos * 5215.0f); // 32768/6.28318
    // W: rad/s → q8 (0-255代表0-6.28318 rad/s)
    motor_s->motor_send_data.comd.spd_des = (int16_t)(motor_s->W * 40.74f);   // 256/6.28318
    // T: N.m → q8 (0-255代表0-1 N.m)
    motor_s->motor_send_data.comd.tor_des = (int16_t)(motor_s->T * 256.0f);
    motor_s->motor_send_data.CRC16 = crc_ccitt(0, (uint8_t *)&motor_s->motor_send_data, sizeof(RIS_ControlData_t) - sizeof(motor_s->motor_send_data.CRC16));
}

/// @brief 解析接收到的原始数据转换为电机反馈数据
/// @param motor_r 要转换的电机数据结构体
void extract_data(MotorData_t *motor_r)
{
	// 初始化接收状态为无效
	motor_r->correct = 0;
	
	// 检查帧头
	if (motor_r->motor_recv_data.head[0] != 0xFD || motor_r->motor_recv_data.head[1] != 0xEE)
	{
		return;
	}
	
	// 计算CRC校验
	motor_r->calc_crc = crc_ccitt(0, (uint8_t *)&motor_r->motor_recv_data, sizeof(RIS_MotorData_t) - sizeof(motor_r->motor_recv_data.CRC16));
	
	// 验证CRC
	if (motor_r->motor_recv_data.CRC16 != motor_r->calc_crc)
	{
		memset(&motor_r->motor_recv_data, 0, sizeof(RIS_MotorData_t));
		motor_r->bad_msg++;          // 递增CRC错误计数
		return;
	}
	else
	{
		// 解析有效数据
		motor_r->motor_id = motor_r->motor_recv_data.mode.id;
		motor_r->mode = motor_r->motor_recv_data.mode.status;
		motor_r->Temp = motor_r->motor_recv_data.fbk.temp;
		motor_r->MError = motor_r->motor_recv_data.fbk.MError;
		motor_r->W = ((float)motor_r->motor_recv_data.fbk.speed / 256) * 6.28318f;
		motor_r->T = ((float)motor_r->motor_recv_data.fbk.torque) / 256;
		motor_r->Pos = 6.28318f * ((float)motor_r->motor_recv_data.fbk.pos) / 32768;
		motor_r->footForce = motor_r->motor_recv_data.fbk.force;
		motor_r->correct = 1;
		return;
	}
}

/**
  * @brief 初始化电机控制器
  */
void MotorController_Init(MotorController* ctrl,
                         UART_HandleTypeDef* uart,
                         GPIO_TypeDef* de_port,
                         uint16_t de_pin) {
    // 初始化硬件参数
    ctrl->uart = uart;
    ctrl->de_port = de_port;
    ctrl->de_pin = de_pin;
    ctrl->dma_busy = 0;
    ctrl->last_sent_motor_id = 0;

    // 初始化所有电机指令
    for (uint8_t i = 0; i < MOTOR_NUM; i++) {
        ctrl->cmds[i].id = i;     // ID从0开始
        ctrl->cmds[i].mode = 1;       // 默认阻尼模式
        ctrl->cmds[i].T = 0.0f;       // 扭矩
        ctrl->cmds[i].W = 0.0f;       // 速度
        ctrl->cmds[i].Pos = 0.0f;     // 位置
        ctrl->cmds[i].K_P = 0.0f;     // 刚度
        ctrl->cmds[i].K_W = 0.0f;     // 阻尼

        modify_data(&ctrl->cmds[i]); // 生成协议数据

        memset(&ctrl->datas[i], 0, sizeof(MotorData_t));
        ctrl->datas[i].motor_id = i;
        ctrl->datas[i].last_received_time = 0; // 初始化接收时间为0
        ctrl->datas[i].correct = 0; // 初始状态为未接收数据
    }
}

/**
  * @brief 设置电机控制参数
  */
void MotorController_SetCommand(MotorController* ctrl,
                              uint8_t motor_id,
                              uint8_t mode,
                              float torque,
                              float speed,
                              float position,
                              float k_p,
                              float k_w) {
    if (motor_id < MOTOR_MIN_ID || motor_id > MOTOR_MAX_ID) return;

    uint8_t idx = motor_id;
    ctrl->cmds[idx].id = motor_id;
    ctrl->cmds[idx].mode = mode;
    ctrl->cmds[idx].T = torque;
    ctrl->cmds[idx].W = speed;
    ctrl->cmds[idx].Pos = position;
    ctrl->cmds[idx].K_P = k_p;
    ctrl->cmds[idx].K_W = k_w;

    modify_data(&ctrl->cmds[idx]);     // 更新协议数据
}

/**
  * @brief 发送单个电机指令
  * @return 0成功, -1失败
  */
/**
  * @brief 检查电机反馈超时
  * @param ctrl: 指向MotorController结构体的指针
  * @retval None
  */
void MotorController_CheckTimeout(MotorController* ctrl) {
    uint32_t current_time = HAL_GetTick();
    
    for (uint8_t i = 0; i < MOTOR_NUM; i++) {
        // 只有当last_received_time不为0时，才检查超时
        if (ctrl->datas[i].last_received_time != 0) {
            // 计算与上次接收数据的时间差
            uint32_t time_diff = current_time - ctrl->datas[i].last_received_time;
            
            // 如果超时时间超过100ms，标记为错误
            if (time_diff > 100) {
                ctrl->datas[i].correct = 0;
                ctrl->datas[i].timeout++; // 递增超时计数
                ctrl->datas[i].consecutive_error++; // 递增连续错误计数
            }
        }
    }
}

/**
  * @brief 清除电机超时计数
  * @param ctrl: 指向MotorController结构体的指针
  * @param motor_id: 电机ID
  * @retval None
  */
void MotorController_ClearTimeout(MotorController* ctrl, uint8_t motor_id) {
    if (motor_id < MOTOR_MIN_ID || motor_id > MOTOR_MAX_ID) return;
    // 更新上次接收时间为当前时间
    ctrl->datas[motor_id].last_received_time = HAL_GetTick();
    ctrl->datas[motor_id].timeout = 0;
    // 重置连续错误计数
    ctrl->datas[motor_id].consecutive_error = 0;
}

/**
  * @brief 发送单个电机指令
  * @return 0成功, -1失败
  */
int MotorController_SendCommand(MotorController* ctrl, uint8_t motor_id) {
    if (motor_id < MOTOR_MIN_ID || motor_id > MOTOR_MAX_ID || ctrl->dma_busy) {
        return -1; // 电机ID无效或DMA正忙
    }

    // 中止当前的DMA接收
    HAL_UART_AbortReceive(ctrl->uart);

    // 初始化接收缓冲区，避免残留数据影响CRC校验
    memset(&ctrl->datas[motor_id].motor_recv_data, 0, sizeof(RIS_MotorData_t));

    ctrl->last_sent_motor_id = motor_id;
    // 设置发送模式
    HAL_GPIO_WritePin(ctrl->de_port, ctrl->de_pin, GPIO_PIN_SET);

    // 标记DMA忙碌状态
    ctrl->dma_busy = 1;

    // 启动DMA发送
    HAL_StatusTypeDef status = HAL_UART_Transmit_DMA(
        ctrl->uart,
        (uint8_t*)&ctrl->cmds[motor_id].motor_send_data,
        sizeof(ctrl->cmds[motor_id].motor_send_data));

    return (status == HAL_OK) ? 0 : -1;
}



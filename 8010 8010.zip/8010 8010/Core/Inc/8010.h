/*
 * 8010.h
 *
 *  Created on: Jan 3, 2026
 *      Author: nianyun
 */

#ifndef INC_8010_H_
#define INC_8010_H_

#include "crc_ccitt.h"
#include "stm32f4xx_hal.h"

#pragma pack(1)
typedef struct
{
    uint8_t id : 4;      // 电机ID: 0,1...,13,14 15表示向所有电机广播数据(此时无返回)
    uint8_t status : 3;  // 工作模式: 0.锁定 1.FOC闭环 2.编码器校准 3.保留
    uint8_t reserve : 1; // 保留位
} RIS_Mode_t;            // 控制模式 1Byte

/**
 * @brief 电机状态控制信息
 */
typedef struct
{
    int16_t tor_des; // 期望关节输出扭矩 unit: N.m      (q8)
    int16_t spd_des; // 期望关节输出速度 unit: rad/s    (q8)
    int32_t pos_des; // 期望关节输出位置 unit: rad      (q15)
    int16_t k_pos;   // 期望关节刚度系数 unit: -1.0-1.0 (q15)
    int16_t k_spd;   // 期望关节阻尼系数 unit: -1.0-1.0 (q15)

} RIS_Comd_t; // 控制参数 12Byte

/**
 * @brief 电机状态反馈信息
 */
typedef struct
{
    int16_t torque;      // 实际关节输出扭矩 unit: N.m     (q8)
    int16_t speed;       // 实际关节输出速度 unit: rad/s   (q8)
    int32_t pos;         // 实际关节输出位置 unit: rad     (q15)
    int8_t temp;         // 电机温度: -128~127°C
    uint8_t MError : 3;  // 电机错误标识: 0.正常 1.过热 2.过流 3.过压 4.编码器故障 5-7.保留
    uint16_t force : 12; // 足端气压传感器数据 12bit (0-4095)
    uint8_t none : 1;    // 保留位
} RIS_Fbk_t;             // 状态数据 11Byte

/**
 * @brief 控制数据包格式
 */
typedef struct
{
    uint8_t head[2]; // 包头         2Byte
    RIS_Mode_t mode; // 电机控制模式  1Byte
    RIS_Comd_t comd; // 电机期望数据 12Byte
    uint16_t CRC16;  // CRC          2Byte

} RIS_ControlData_t; // 主机控制命令     17Byte

/**
 * @brief 电机反馈数据包格式
 */
typedef struct
{
    uint8_t head[2]; // 包头         2Byte
    RIS_Mode_t mode; // 电机控制模式  1Byte
    RIS_Fbk_t fbk;   // 电机反馈数据 11Byte
    uint16_t CRC16;  // CRC          2Byte

} RIS_MotorData_t; // 电机返回数据     16Byte

#pragma pack()

/// @brief 电机指令结构体
typedef struct
{
    unsigned short id;   // 电机ID，15代表广播数据包
    unsigned short mode; // 0:空闲 1:FOC控制 2:电机标定
    float T;             // 期望关节的输出力矩(电机本身的力矩)(Nm)
    float W;             // 期望关节速度(电机本身的速度)(rad/s)
    float Pos;           // 期望关节位置(rad)
    float K_P;           // 关节刚度系数(0-25.599)
    float K_W;           // 关节速度系数(0-25.599)

    RIS_ControlData_t motor_send_data;

} MotorCmd_t;

/// @brief 电机反馈结构体
typedef struct
{
    unsigned char motor_id; // 电机ID
    unsigned char mode;     // 0:空闲 1:FOC控制 2:电机标定
    int Temp;               // 温度
    int MError;             // 错误码
    float T;                // 当前实际电机输出力矩(电机本身的力矩)(Nm)
    float W;                // 当前实际电机速度(电机本身的速度)(rad/s)
    float Pos;              // 当前电机位置(rad)
    int correct;            // 接收数据是否完整(1完整，0不完整)
    int footForce;          // 足端力传感器原始数值

    uint16_t calc_crc;
    uint32_t last_received_time; // 上次成功接收数据的时间戳(ms)
    uint32_t timeout;       // 通讯超时 数量
    uint32_t bad_msg;       // CRC校验错误 数量
    uint32_t consecutive_error; // 连续错误计数
    RIS_MotorData_t motor_recv_data; // 电机接收数据结构体

} MotorData_t;

// 配置参数
#define MOTOR_NUM         8      // 电机数量
#define MOTOR_MIN_ID      0      // 最小电机ID
#define MOTOR_MAX_ID      7      // 最大电机ID
#define CMD_TIMEOUT_MS    10      // 指令发送超时时间

// 电机控制结构体
typedef struct {
	MotorData_t datas[MOTOR_NUM];//每个电机的返回值
    MotorCmd_t cmds[MOTOR_NUM];// 每个电机的指令
    UART_HandleTypeDef* uart;     // 使用的UART句柄
    GPIO_TypeDef* de_port;        // RS485方向控制端口
    uint16_t de_pin;              // RS485方向控制引脚
    volatile uint8_t dma_busy;    // DMA忙碌状态标记
    uint8_t last_sent_motor_id;   // 最后发送的电机ID
} MotorController;

// 函数声明
void modify_data(MotorCmd_t *motor_s);
void extract_data(MotorData_t *motor_r);

// 全局电机控制器实例声明
extern MotorController ctrl;

// 电机控制器函数声明
void MotorController_Init(MotorController* ctrl,
                         UART_HandleTypeDef* uart,
                         GPIO_TypeDef* de_port,
                         uint16_t de_pin
                         );

void MotorController_SetCommand(MotorController* ctrl,
                              uint8_t motor_id,
                              uint8_t mode,
                              float torque,
                              float speed,
                              float position,
                              float k_p,
                              float k_w);

int MotorController_SendCommand(MotorController* ctrl,
                              uint8_t motor_id);

void MotorController_CheckTimeout(MotorController* ctrl);
void MotorController_ClearTimeout(MotorController* ctrl, uint8_t motor_id);

#endif /* INC_8010_H_ */

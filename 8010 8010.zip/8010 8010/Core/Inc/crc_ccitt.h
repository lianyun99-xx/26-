/*
 * crc_ccitt.h
 *
 *  Created on: Jan 3, 2026
 *      Author: nianyun
 */

#ifndef INC_CRC_CCITT_H_
#define INC_CRC_CCITT_H_

#include <stdint.h>
#include <stddef.h>

uint16_t crc_ccitt_byte(uint16_t crc, const uint8_t c);
uint16_t crc_ccitt(uint16_t crc, uint8_t const *buffer, size_t len);

#endif /* INC_CRC_CCITT_H_ */
